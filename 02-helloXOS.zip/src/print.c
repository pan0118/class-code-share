#include "print.h"
#include "sbi.h"

void print_string(const char *str) {
    while (*str) {
        print_char(*str++);
    }
}

void print_char(char c) {
    console_putchar(c);
}


