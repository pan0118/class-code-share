#include "print.h"
void main(void) {
    print_string("RISC-V Bootloader\n");
    print_string("Hello XOS!\n");

    // 进入无限循环
    while (1) {
        // 无限循环
    }
}