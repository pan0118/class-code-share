#ifndef PRINT_H
#define PRINT_H

void print_string(const char *str);
void print_char(char c);

#endif // PRINT_H