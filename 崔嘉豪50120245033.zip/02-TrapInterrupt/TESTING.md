# 实验2测试指南

## 快速开始

### 1. 编译项目
```bash
cd /home/zx/Downloads/02-TrapInterrupt
make clean
make
```

### 2. 运行测试
```bash
make run
```

或者手动运行：
```bash
qemu-system-riscv64 -machine virt -nographic -bios none -kernel out/kernel.elf -bios ./lib/rustsbi-qemu/rustsbi-qemu.bin
```

## 预期输出

### 启动阶段
```
RISC-V Bootloader
Hello XOS!
=========================
Interrupt system initialized
Timer interrupt enabled
External interrupt enabled
=========================
```

### 异常处理测试

#### 测试1: 断点异常
```
=== Test: Breakpoint ===
Executing ebreak instruction...

[Exception] Breakpoint (code=3)
  stval = 0x..., epc = 0x...
  -> Breakpoint hit (ebreak instruction)
Returned from breakpoint handler
```

#### 测试2: 非法指令
```
=== Test: Illegal Instruction ===
Executing illegal instruction...

[Exception] Illegal Instruction (code=2)
  stval = 0x..., epc = 0x...
  -> Illegal instruction encountered
  -> Invalid instruction at 0x...
Returned from illegal instruction handler
```

#### 测试3: 访问故障
```
=== Test: Load/Store Access Fault ===
Attempting to read from invalid address 0x00000000...

[Exception] Store Access Fault (code=7)
  stval = 0x0, epc = 0x...
  -> Store access fault at address 0x00000000
```

### 中断测试

#### 时钟中断（周期性出现）
```
[Interrupt] Supervisor Timer Interrupt (code=5)
  -> Timer interrupt #1

[Interrupt] Supervisor Timer Interrupt (code=5)
  -> Timer interrupt #2

...（持续出现）
```

#### UART外部中断
```
[Test 3] Simulating UART Interrupt

[Interrupt] Supervisor Software Interrupt (code=1)
  -> Software interrupt

[Interrupt] Supervisor External Interrupt (code=9)
  -> UART interrupt received
  -> Simulating character reception
```

### 主循环
```
Entering main loop (timer interrupts will continue)...

（后台持续显示时钟中断和UART中断）
```

## 验证要点

### ✓ 时钟中断验证
1. 观察是否定期出现"Timer interrupt #N"消息
2. 计数器N应该递增
3. 中断间隔约为1秒（取决于QEMU模拟的时钟频率）

### ✓ UART中断验证
1. 在主循环中定期出现"UART interrupt received"
2. 确认外部中断能够被正确触发和处理

### ✓ 异常处理验证
1. **断点测试**: ebreak指令后程序能继续执行
2. **非法指令**: 系统识别并跳过非法指令
3. **访问故障**: 捕获内存访问错误并恢复

### ✓ 中断嵌套验证
1. 观察是否有中断在处理期间被另一个中断打断
2. 检查嵌套深度不超过3层

## 调试技巧

### 1. 查看详细寄存器状态
当发生异常时，系统会打印完整的trapframe信息：
```
trapframe at 0x...
  zero     0x0
  ra       0x...
  sp       0x...
  ...
  status   0x...
  epc      0x...
  stval    0x...
  cause    0x...
```

### 2. 修改测试参数

**调整时钟中断频率：**
编辑 `src/trap.c` 中的 `set_next_timer()` 函数：
```c
uint64 next_time = current_time + 10000000; // 改小这个值提高频率
```

**修改UART中断间隔：**
编辑 `src/main.c` 的主循环：
```c
for(volatile int i = 0; i < 50000000; i++); // 改小这个值提高频率
```

### 3. 添加自定义测试

在 `src/main.c` 中添加新的测试函数：
```c
void my_custom_test() {
    printf("\n=== My Custom Test ===\n");
    // 你的测试代码
}
```

然后在 `main()` 中调用它。

### 4. 启用/禁用特定功能

**禁用时钟中断：**
注释掉 `kernel_trap_init()` 中的 `timer_init()` 调用

**禁用UART模拟：**
注释掉 `simulate_uart_interrupt()` 调用

## 常见问题

### Q1: 没有看到时钟中断？
**A:** 检查以下几点：
1. 确认SBI TIME扩展被QEMU支持
2. 检查 `w_sie()` 是否正确设置了STIE位
3. 确认 `intr_on()` 已调用

### Q2: 异常处理后程序崩溃？
**A:** 
1. 检查 `trapentry.S` 中的上下文保存/恢复是否正确
2. 确认 `tf->epc` 被正确更新以跳过异常指令
3. 查看寄存器状态找出问题

### Q3: 中断嵌套没有发生？
**A:**
1. 确认 `enable_nested_interrupts()` 在中断处理中被调用
2. 检查 `SSTATUS_SPIE` 位的设置
3. 可能需要调整中断触发频率

### Q4: 编译错误？
**A:**
1. 确认RISC-V工具链已正确安装
2. 检查所有头文件包含路径
3. 运行 `make clean` 后重新编译

## 扩展实验

### 实验1: 修改时钟频率
尝试不同的定时器间隔，观察系统行为变化。

### 实验2: 添加新的异常类型
实现未对齐访问的自动修复（如将2字节读取拆分为两个1字节读取）。

### 实验3: 中断优先级
修改代码使某些中断优先于其他中断处理。

### 实验4: 性能分析
统计不同异常和中断的处理时间。

## 提交检查清单

- [ ] 代码能够成功编译
- [ ] 时钟中断正常工作
- [ ] UART外部中断能够触发
- [ ] 至少3种异常类型被正确处理
- [ ] 中断嵌套机制工作
- [ ] 所有测试用例通过
- [ ] README文档已更新
- [ ] 代码有适当的注释