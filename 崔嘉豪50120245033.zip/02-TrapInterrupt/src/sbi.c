#include "sbi.h"
#include "types.h"

// 新的SBI调用接口（支持扩展ID和功能ID）
struct sbiret sbi_call(long arg0, long arg1, long arg2, long arg3, 
                       long arg4, long arg5, long fid, long eid)
{
    register long a0 asm("a0") = arg0;
    register long a1 asm("a1") = arg1;
    register long a2 asm("a2") = arg2;
    register long a3 asm("a3") = arg3;
    register long a4 asm("a4") = arg4;
    register long a5 asm("a5") = arg5;
    register long a6 asm("a6") = fid;
    register long a7 asm("a7") = eid;
    
    struct sbiret ret;
    
    asm volatile("ecall"
                 : "=r"(a0), "=r"(a1)
                 : "r"(a0), "r"(a1), "r"(a2), "r"(a3), "r"(a4), "r"(a5), "r"(a6), "r"(a7)
                 : "memory");
    
    ret.error = a0;
    ret.value = a1;
    return ret;
}

// 兼容旧的SBI调用接口
int sbi_call_legacy(enum sbi_call_type which, uint64 arg0, uint64 arg1, uint64 arg2)
{
    register uint64 a0 asm("a0") = arg0;
    register uint64 a1 asm("a1") = arg1;
    register uint64 a2 asm("a2") = arg2;
    register uint64 a7 asm("a7") = which;
    int ret;
    asm volatile("ecall"
                 : "=r"(ret)
                 : "r"(a0), "r"(a1), "r"(a2), "r"(a7)
                 : "memory");
    if (ret < 0) {
        return -1;
    }
    return ret;
}

void console_putchar(int c)
{
    sbi_call_legacy(SBI_CONSOLE_PUTCHAR, c, 0, 0);
}

int console_getchar()
{
    return sbi_call_legacy(SBI_CONSOLE_GETCHAR, 0, 0, 0);
}

void shutdown()
{
    sbi_call_legacy(SBI_SHUTDOWN, 0, 0, 0);
}

// 设置定时器（使用新的SBI TIME扩展）
void sbi_set_timer(uint64 stime_value)
{
    // SBI TIME扩展: eid=0x54494D45, fid=0
    sbi_call(stime_value, 0, 0, 0, 0, 0, 0, SBI_EXT_TIME);
}