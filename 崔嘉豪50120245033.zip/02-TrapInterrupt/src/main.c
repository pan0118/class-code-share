#include "print.h"
#include "trap.h"

// 外部声明测试函数
extern void test_all_exceptions(void);
extern void simulate_uart_interrupt(void);

void trap_test(){
    printf("*(int *)0x00000000 = 100\n");

	/*
	 * Synchronous exception code = 7
	 * Store/AMO access fault
	 */
	*(int *)0x00000000 = 100;
	print_string("Yeah! I'm return back from trap!\n");
}


void test_interrupts() {
    print_string("\n=== Testing Interrupts ===\n");
    
    // 测试1: 存储访问故障
    print_string("\n[Test 1] Store Access Fault Test\n");
    trap_test();
    
    // 等待一段时间让时钟中断触发
    print_string("\n[Test 2] Waiting for timer interrupts...\n");
    for(volatile int i = 0; i < 10000000; i++);
    
    // 测试3: 模拟UART中断
    print_string("\n[Test 3] Simulating UART Interrupt\n");
    simulate_uart_interrupt();
    
    // 再次等待让UART中断处理
    for(volatile int i = 0; i < 1000000; i++);
    
    print_string("\nInterrupt tests completed.\n");
}

void test_exception_handling() {
    print_string("\n=== Testing Exception Handling ===\n");
    
    // 运行所有异常测试
    test_all_exceptions();
}

void main(void) {
    print_string("RISC-V Bootloader\n");
    print_string("Hello XOS!\n");
    print_string("=========================\n");

    // 初始化中断处理
    init_interrupt();
    
    print_string("Interrupt system initialized\n");
    print_string("Timer interrupt enabled\n");
    print_string("External interrupt enabled\n");
    print_string("=========================\n");

    // 测试异常处理
    test_exception_handling();
    
    // 测试中断
    test_interrupts();

    // 进入无限循环，持续接收时钟中断
    print_string("\nEntering main loop (timer interrupts will continue)...\n");
    while (1) {
        // 定期模拟UART中断
        for(volatile int i = 0; i < 50000000; i++);
        simulate_uart_interrupt();
    }
}