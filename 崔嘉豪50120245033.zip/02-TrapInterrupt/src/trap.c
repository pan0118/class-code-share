#include "defs.h"
#include "trap.h"

extern void trap_vector();

// 中断嵌套深度计数
static volatile int interrupt_nesting = 0;

// UART中断模拟标志
static volatile int uart_interrupt_pending = 0;

// 时钟中断计数器
static volatile uint64 timer_interrupt_count = 0;

void kernel_trap_init()
{
    // 设置stvec指向trap_vector
    w_stvec((uint64)trap_vector);
    
    // 初始化时钟中断
    timer_init();
    
    // 初始化UART中断模拟
    uart_interrupt_init();
    
    // 使能 Supervisor 外部中断和定时器中断
    w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    
    // 使能全局中断
    intr_on();
}

void init_interrupt() {
    kernel_trap_init();
}

// ==================== 时钟中断相关 ====================

void timer_init(void)
{
    // 设置第一个定时器中断
    set_next_timer();
}

void set_next_timer(void)
{
    // 获取当前时间并设置下一个中断（1秒后）
    uint64 current_time = r_time();
    uint64 next_time = current_time + 10000000; // 假设10MHz时钟，1秒=10^7个周期
    
    sbi_set_timer(next_time);
}

// ==================== UART中断模拟 ====================

void uart_interrupt_init(void)
{
    // 初始化UART中断状态
    uart_interrupt_pending = 0;
}

void simulate_uart_interrupt(void)
{
    // 模拟UART接收中断
    uart_interrupt_pending = 1;
    
    // 触发软件中断来模拟外部中断
    // 在实际硬件中，这由UART控制器触发
    w_sip(r_sip() | (1 << 1)); // 设置SSIP位
}

// ==================== 中断嵌套支持 ====================

void enable_nested_interrupts(void)
{
    // 在中断处理期间允许嵌套中断
    w_sstatus(r_sstatus() | SSTATUS_SPIE);
}

void disable_nested_interrupts(void)
{
    // 禁止嵌套中断
    w_sstatus(r_sstatus() & ~SSTATUS_SPIE);
}

// ==================== 打印函数 ====================

void print_trapframe(struct trapframe *tf) {
    printf("trapframe at %p\n", tf);
    print_regs(&tf->gpr);
    printf("  status   0x%lx\n", tf->status);
    printf("  epc      0x%lx\n", tf->epc);
    printf("  stval    0x%lx\n", tf->stval);
    printf("  cause    0x%lx\n", tf->cause);
}

void print_csr(struct trapframe *tf) {
    printf("  status   0x%lx\n", tf->status);
    printf("  epc      0x%lx\n", tf->epc);
    printf("  stval    0x%lx\n", tf->stval);
    printf("  cause    0x%lx\n", tf->cause);
}

void print_regs(struct pushregs *gpr) {
    printf("  zero     0x%lx\n", gpr->zero);
    printf("  ra       0x%lx\n", gpr->ra);
    printf("  sp       0x%lx\n", gpr->sp);
    printf("  gp       0x%lx\n", gpr->gp);
    printf("  tp       0x%lx\n", gpr->tp);
    printf("  t0       0x%lx\n", gpr->t0);
    printf("  t1       0x%lx\n", gpr->t1);
    printf("  t2       0x%lx\n", gpr->t2);
    printf("  s0       0x%lx\n", gpr->s0);
    printf("  s1       0x%lx\n", gpr->s1);
    printf("  a0       0x%lx\n", gpr->a0);
    printf("  a1       0x%lx\n", gpr->a1);
    printf("  a2       0x%lx\n", gpr->a2);
    printf("  a3       0x%lx\n", gpr->a3);
    printf("  a4       0x%lx\n", gpr->a4);
    printf("  a5       0x%lx\n", gpr->a5);
    printf("  a6       0x%lx\n", gpr->a6);
    printf("  a7       0x%lx\n", gpr->a7);
    printf("  s2       0x%lx\n", gpr->s2);
    printf("  s3       0x%lx\n", gpr->s3);
    printf("  s4       0x%lx\n", gpr->s4);
    printf("  s5       0x%lx\n", gpr->s5);
    printf("  s6       0x%lx\n", gpr->s6);
    printf("  s7       0x%lx\n", gpr->s7);
    printf("  s8       0x%lx\n", gpr->s8);
    printf("  s9       0x%lx\n", gpr->s9);
    printf("  s10      0x%lx\n", gpr->s10);
    printf("  s11      0x%lx\n", gpr->s11);
    printf("  t3       0x%lx\n", gpr->t3);
    printf("  t4       0x%lx\n", gpr->t4);
    printf("  t5       0x%lx\n", gpr->t5);
    printf("  t6       0x%lx\n", gpr->t6);
}

// ==================== 异常处理 ====================

const char* exception_name(uint64 cause) {
    switch(cause) {
        case InstructionMisaligned: return "Instruction Misaligned";
        case InstructionAccessFault: return "Instruction Access Fault";
        case IllegalInstruction: return "Illegal Instruction";
        case Breakpoint: return "Breakpoint";
        case LoadMisaligned: return "Load Misaligned";
        case LoadAccessFault: return "Load Access Fault";
        case StoreMisaligned: return "Store Misaligned";
        case StoreAccessFault: return "Store Access Fault";
        case UserEnvCall: return "User Environment Call";
        case SupervisorEnvCall: return "Supervisor Environment Call";
        case MachineEnvCall: return "Machine Environment Call";
        case InstructionPageFault: return "Instruction Page Fault";
        case LoadPageFault: return "Load Page Fault";
        case StorePageFault: return "Store Page Fault";
        default: return "Unknown Exception";
    }
}

const char* interrupt_name(uint64 cause) {
    switch(cause) {
        case UserSoft: return "User Software Interrupt";
        case SupervisorSoft: return "Supervisor Software Interrupt";
        case UserTimer: return "User Timer Interrupt";
        case SupervisorTimer: return "Supervisor Timer Interrupt";
        case UserExternal: return "User External Interrupt";
        case SupervisorExternal: return "Supervisor External Interrupt";
        default: return "Unknown Interrupt";
    }
}

// 异常处理程序
void handle_exception(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    
    printf("\n[Exception] %s (code=%ld)\n", exception_name(cause_code), cause_code);
    printf("  stval = 0x%lx, epc = 0x%lx\n", tf->stval, tf->epc);
    
    switch(cause_code) {
        case InstructionMisaligned:
            printf("  -> Instruction address is not aligned to instruction boundary\n");
            // 跳过非法指令
            tf->epc = tf->epc + 4;
            break;
            
        case InstructionAccessFault:
            printf("  -> Instruction fetch access fault\n");
            panic("Cannot recover from instruction access fault");
            break;
            
        case IllegalInstruction:
            printf("  -> Illegal instruction encountered\n");
            printf("  -> Invalid instruction at 0x%lx\n", tf->stval);
            // 跳过非法指令
            tf->epc = tf->epc + 4;
            break;
            
        case Breakpoint:
            printf("  -> Breakpoint hit (ebreak instruction)\n");
            // 继续执行下一条指令
            tf->epc = tf->epc + 4;
            break;
            
        case LoadMisaligned:
            printf("  -> Load address 0x%lx is misaligned\n", tf->stval);
            // 跳过导致异常的指令
            tf->epc = tf->epc + 4;
            break;
            
        case LoadAccessFault:
            printf("  -> Load access fault at address 0x%lx\n", tf->stval);
            // 跳过导致异常的指令
            tf->epc = tf->epc + 4;
            break;
            
        case StoreMisaligned:
            printf("  -> Store address 0x%lx is misaligned\n", tf->stval);
            // 跳过导致异常的指令
            tf->epc = tf->epc + 4;
            break;
            
        case StoreAccessFault:
            printf("  -> Store access fault at address 0x%lx\n", tf->stval);
            // 跳过导致异常的指令
            tf->epc = tf->epc + 4;
            break;
            
        case SupervisorEnvCall:
            printf("  -> Supervisor environment call (ecall)\n");
            // ecall是合法的，继续执行下一条指令
            tf->epc = tf->epc + 4;
            break;
            
        default:
            printf("  -> Unhandled exception\n");
            print_csr(tf);
            // 对于未处理的异常，也尝试跳过
            tf->epc = tf->epc + 4;
            break;
    }
}

// ==================== 中断处理 ====================

void handle_interrupt(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    
    printf("\n[Interrupt] %s (code=%ld)\n", interrupt_name(cause_code), cause_code);
    
    // 增加嵌套深度
    interrupt_nesting++;
    
    switch(cause_code) {
        case SupervisorTimer:
            // 处理定时器中断
            timer_interrupt_count++;
            printf("  -> Timer interrupt #%ld\n", timer_interrupt_count);
            
            // 设置下一个定时器中断
            set_next_timer();
            
            // 如果嵌套深度较浅，允许嵌套中断
            if (interrupt_nesting < 3) {
                enable_nested_interrupts();
            }
            break;
            
        case SupervisorExternal:
            // 处理外部中断（如UART）
            if (uart_interrupt_pending) {
                printf("  -> UART interrupt received\n");
                printf("  -> Simulating character reception\n");
                uart_interrupt_pending = 0;
            } else {
                printf("  -> External interrupt from unknown device\n");
            }
            break;
            
        case SupervisorSoft:
            printf("  -> Software interrupt\n");
            // 清除软件中断标志
            w_sip(r_sip() & ~(1 << 1));
            break;
            
        default:
            printf("  -> Unknown interrupt type\n");
            break;
    }
    
    // 减少嵌套深度
    interrupt_nesting--;
    
    // 恢复中断状态
    disable_nested_interrupts();
}

// 中断和异常处理的入口
static inline void trap_handler(struct trapframe *tf) {
    if (tf->cause & SCAUSE_MASK_INTERRUPT) {
        // 中断处理
        handle_interrupt(tf);
    } else {
        // 异常处理
        handle_exception(tf);
    }
}

void trap(struct trapframe *tf) { 
    trap_handler(tf); 
}

// ==================== 测试函数 ====================

// 测试1: 非法指令异常
void test_illegal_instruction(void) {
    printf("\n=== Test: Illegal Instruction ===\n");
    
    // 定义一个非法指令（全0通常不是有效的RISC-V指令）
    volatile uint32 illegal_instr = 0x00000000;
    
    // 使用函数指针执行非法指令
    void (*func_ptr)(void) = (void (*)(void))&illegal_instr;
    
    printf("Executing illegal instruction...\n");
    func_ptr();
    
    printf("Returned from illegal instruction handler\n");
}

// 测试2: 断点异常
void test_breakpoint(void) {
    printf("\n=== Test: Breakpoint ===\n");
    
    printf("Executing ebreak instruction...\n");
    
    // 执行ebreak指令触发断点异常
    asm volatile("ebreak");
    
    printf("Returned from breakpoint handler\n");
}

// 测试3: 加载/存储访问故障
void test_load_store_access_fault(void) {
    printf("\n=== Test: Load/Store Access Fault ===\n");
    
    // 尝试访问无效地址
    printf("Attempting to read from invalid address 0x00000000...\n");
    volatile int val = *(volatile int *)0x00000000;
    
    printf("Value read: %d (should not reach here normally)\n", val);
}

// 综合测试所有异常
void test_all_exceptions(void) {
    printf("\n========================================\n");
    printf("Starting Exception Handling Tests\n");
    printf("========================================\n");
    
    // 测试断点
    test_breakpoint();
    
    // 测试非法指令
    test_illegal_instruction();
    
    // 测试访问故障
    test_load_store_access_fault();
    
    printf("\n========================================\n");
    printf("All Exception Tests Completed\n");
    printf("========================================\n");
}