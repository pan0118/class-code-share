#ifndef SBI_H
#define SBI_H

#include "types.h"

enum sbi_ext_id {
    SBI_EXT_BASE = 0x10,
    SBI_EXT_TIME = 0x54494D45,  // 'TIME'
    SBI_EXT_IPI = 0x735049,     // 'sPI'
};

enum sbi_call_type {
    SBI_SET_TIMER = 0,
    SBI_CONSOLE_PUTCHAR = 1,
    SBI_CONSOLE_GETCHAR = 2,
    SBI_CLEAR_IPI = 3,
    SBI_SEND_IPI = 4,
    SBI_REMOTE_FENCE_I = 5,
    SBI_REMOTE_SFENCE_VMA = 6,
    SBI_REMOTE_SFENCE_VMA_ASID = 7,
    SBI_SHUTDOWN = 8
};

// SBI调用返回结构
struct sbiret {
    long error;
    long value;
};

// 新的SBI调用接口（支持扩展）
struct sbiret sbi_call(long arg0, long arg1, long arg2, long arg3, 
                       long arg4, long arg5, long fid, long eid);

// 兼容旧接口
int sbi_call_legacy(enum sbi_call_type which, uint64 arg0, uint64 arg1, uint64 arg2);

void console_putchar(int);
int console_getchar();
void shutdown();

// 时钟相关SBI调用
void sbi_set_timer(uint64 stime_value);

#endif // SBI_H