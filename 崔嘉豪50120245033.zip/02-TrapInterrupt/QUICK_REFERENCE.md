# 实验2快速参考

## 🚀 快速开始

```bash
cd /home/zx/Downloads/02-TrapInterrupt
make clean && make && make run
```

## 📋 核心API

### 中断初始化
```c
init_interrupt();  // 在main()中调用一次
```

### 时钟中断
```c
timer_init();       // 自动在init_interrupt()中调用
set_next_timer();   // 设置下一个中断时间
```

### 外部中断模拟
```c
simulate_uart_interrupt();  // 触发UART中断
```

### 异常测试
```c
test_breakpoint();              // 测试ebreak
test_illegal_instruction();     // 测试非法指令
test_load_store_access_fault(); // 测试访问故障
test_all_exceptions();          // 运行所有测试
```

## 🔍 CSR寄存器速查

| 寄存器 | 读函数 | 写函数 | 用途 |
|--------|--------|--------|------|
| stvec | `r_stvec()` | `w_stvec(x)` | Trap向量基地址 |
| scause | `r_scause()` | - | 异常/中断原因 |
| sepc | `r_sepc()` | `w_sepc(x)` | 返回地址 |
| stval | `r_stval()` | - | 异常相关信息 |
| sstatus | `r_sstatus()` | `w_sstatus(x)` | 状态寄存器 |
| sie | `r_sie()` | `w_sie(x)` | 中断使能 |
| sip | `r_sip()` | `w_sip(x)` | 中断pending |
| time | `r_time()` | - | 时间计数器 |

## ⚡ 中断/异常代码速查

### 中断 (第63位=1)
```
SupervisorSoft     = 1   // 软件中断
SupervisorTimer    = 5   // 定时器中断 ⏰
SupervisorExternal = 9   // 外部中断 📡
```

### 异常 (第63位=0)
```
InstructionMisaligned    = 0  // 指令未对齐
InstructionAccessFault   = 1  // 指令访问故障
IllegalInstruction       = 2  // 非法指令 ❌
Breakpoint               = 3  // 断点 🔴
LoadMisaligned           = 4  // 加载未对齐
LoadAccessFault          = 5  // 加载访问故障
StoreMisaligned          = 6  // 存储未对齐
StoreAccessFault         = 7  // 存储访问故障 ⚠️
SupervisorEnvCall        = 9  // ecall
```

## 🛠️ 常用操作

### 判断中断vs异常
```c
if (tf->cause & SCAUSE_MASK_INTERRUPT) {
    // 中断处理
} else {
    // 异常处理
}
```

### 跳过当前指令
```c
tf->epc += 4;  // RISC-V指令固定4字节
```

### 使能/禁用中断
```c
intr_on();   // 使能全局中断
intr_off();  // 禁用全局中断
```

### 使能特定中断
```c
w_sie(r_sie() | SIE_STIE);  // 使能定时器中断
w_sie(r_sie() | SIE_SEIE);  // 使能外部中断
```

## 🐛 调试技巧

### 打印trapframe
```c
print_trapframe(tf);  // 打印完整上下文
print_csr(tf);        // 只打印CSR寄存器
print_regs(&tf->gpr); // 只打印通用寄存器
```

### 查看异常原因
```c
uint64 cause = tf->cause & SCAUSE_MASK_ECODE;
printf("Exception: %s\n", exception_name(cause));
```

### QEMU调试
```bash
# Terminal 1: 启动QEMU等待GDB
qemu-system-riscv64 -machine virt -nographic \
  -kernel out/kernel.elf -bios rustsbi-qemu.bin \
  -S -s

# Terminal 2: 连接GDB
gdb-multiarch out/kernel.elf
(gdb) target remote localhost:1234
(gdb) break trap_vector
(gdb) continue
```

## 📊 性能参数

### 栈空间使用
- trapframe大小: 288字节
- 每层嵌套: ~480字节
- 最大嵌套深度: 3层
- 总栈大小: 4KB

### 时钟中断间隔
- 默认: 10,000,000个周期
- 约等于: 1秒（假设10MHz时钟）
- 调整位置: `trap.c::set_next_timer()`

## 🔧 常见问题解决

### Q: 没有时钟中断？
```c
// 检查清单
✓ w_sie() 设置了 SIE_STIE
✓ sbi_set_timer() 被调用
✓ intr_on() 已执行
✓ stvec 正确设置
```

### Q: 异常后崩溃？
```c
// 确保 ep c 被更新
tf->epc += 4;

// 检查寄存器恢复
// 查看 trapentry.S 的 restore_all
```

### Q: 嵌套不工作？
```c
// 确认 SPIE 位设置
enable_nested_interrupts();
// 等价于: w_sstatus(r_sstatus() | SSTATUS_SPIE);
```

## 📝 修改示例

### 改变时钟频率
```c
// 文件: src/trap.c::set_next_timer()
void set_next_timer(void) {
    uint64 current_time = r_time();
    // 改小这个值 = 更高频率
    uint64 next_time = current_time + 5000000;  // 0.5秒
    sbi_set_timer(next_time);
}
```

### 添加新异常处理
```c
// 文件: src/trap.c::handle_exception()
switch(cause_code) {
    // ... 现有case ...
    
    case YourNewException:
        printf("Handling your exception\n");
        tf->epc += 4;
        break;
}
```

### 添加新中断类型
```c
// 文件: src/trap.c::handle_interrupt()
switch(cause_code) {
    // ... 现有case ...
    
    case YourNewInterrupt:
        printf("Handling your interrupt\n");
        break;
}
```

## 🎯 实验检查清单

提交前确认：
- [ ] 代码编译无警告 (`make` 成功)
- [ ] 时钟中断正常工作（看到 Timer interrupt #N）
- [ ] UART中断被触发（看到 UART interrupt received）
- [ ] 至少3种异常被正确处理
- [ ] 中断嵌套工作（nesting计数变化）
- [ ] 所有测试用例通过
- [ ] README已更新
- [ ] 代码有注释

## 📖 相关文档

- `Readme` - 项目说明和功能介绍
- `TESTING.md` - 详细测试指南
- `ARCHITECTURE.md` - 系统架构详解
- `SUMMARY.md` - 完成总结

## 💡 提示

> **最佳实践:**
> 1. 始终在修改后运行 `make clean && make`
> 2. 使用 `print_trapframe()` 调试问题
> 3. 先测试简单场景，再逐步复杂化
> 4. 保留原始代码备份
> 5. 记录遇到的问题和解决方案

---

**祝实验顺利！** 🎉