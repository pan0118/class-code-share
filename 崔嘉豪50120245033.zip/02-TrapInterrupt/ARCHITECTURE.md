# 中断和异常处理架构说明

## 系统架构图

```
┌─────────────────────────────────────────────────┐
│                  应用程序 (main.c)                │
│  - 初始化中断系统                                 │
│  - 触发测试用例                                   │
│  - 主循环                                         │
└──────────────────┬──────────────────────────────┘
                   │ ecall / 异常 / 中断
┌──────────────────▼──────────────────────────────┐
│            Trap Entry (trapentry.S)              │
│  - save_all: 保存所有寄存器到trapframe           │
│  - 调用 C 语言 trap() 函数                       │
│  - restore_all: 恢复寄存器                       │
│  - sret: 返回                                    │
└──────────────────┬──────────────────────────────┘
                   │
┌──────────────────▼──────────────────────────────┐
│          Trap Handler (trap.c)                   │
│                                                  │
│  ┌───────────────────────────────────────────┐  │
│  │         trap()                             │  │
│  │           ↓                                │  │
│  │      trap_handler()                        │  │
│  │         ↓    ↓                             │  │
│  │   中断？   异常？                          │  │
│  │     ↓        ↓                             │  │
│  │ handle_   handle_                          │  │
│  │interrupt  exception                        │  │
│  └───────────────────────────────────────────┘  │
└──────────────────┬──────────────────────────────┘
                   │
         ┌─────────┴─────────┐
         ↓                   ↓
┌────────────────┐  ┌────────────────┐
│  中断处理       │  │  异常处理       │
│                │  │                 │
│ • 时钟中断     │  │ • 断点          │
│ • UART中断     │  │ • 非法指令      │
│ • 软件中断     │  │ • 访问故障      │
│ • 嵌套控制     │  │ • 未对齐访问    │
└────────┬───────┘  └────────┬───────┘
         │                   │
         └─────────┬─────────┘
                   │ SBI调用
         ┌─────────▼─────────┐
         │   SBI Layer       │
         │   (sbi.c)         │
         │                   │
         │ • console_putchar │
         │ • sbi_set_timer   │
         │ • shutdown        │
         └─────────┬─────────┘
                   │ ecall
         ┌─────────▼─────────┐
         │  RustSBI / M-mode │
         └───────────────────┘
```

## 数据流

### 1. 中断处理流程

```
硬件中断发生
    ↓
CPU自动: 
  - 保存pc到sepc
  - 保存status到sstatus
  - 设置cause寄存器
  - 跳转到stvec指向的地址
    ↓
trap_vector (trapentry.S)
  - save_all宏保存36个寄存器
  - 构建trapframe结构
    ↓
trap() (trap.c)
  - 判断是中断还是异常
    ↓
handle_interrupt()
  - 识别中断类型 (timer/external/software)
  - 增加嵌套计数
  - 执行特定中断处理
  - 减少嵌套计数
    ↓
__trapret (trapentry.S)
  - restore_all宏恢复寄存器
  - sret返回
    ↓
继续执行被中断的代码
```

### 2. 异常处理流程

```
异常指令执行 (如ebreak, 非法指令)
    ↓
CPU同步陷阱:
  - 保存上下文
  - 跳转到stvec
    ↓
trap_vector (trapentry.S)
  - 保存所有寄存器
    ↓
trap() (trap.c)
  - 识别为异常
    ↓
handle_exception()
  - 根据cause code分类处理
  - 打印异常信息
  - 决定恢复策略:
    * 跳过指令 (epc += 4)
    * 或 panic
    ↓
__trapret
  - 恢复上下文
  - sret返回
    ↓
从下一条指令继续执行
```

## 关键数据结构

### trapframe 结构

```c
struct trapframe {
    struct pushregs gpr;   // 32个通用寄存器
    uintptr status;         // sstatus寄存器
    uintptr epc;            // 返回地址
    uintptr stval;          // 异常相关信息
    uintptr cause;          // 异常/中断原因
};
```

**内存布局:**
```
sp -> [x0]       偏移 0
      [x1/ra]    偏移 8
      [sp]       偏移 16  (旧sp值)
      [x3-x31]   偏移 24-264
      [sstatus]  偏移 256
      [sepc]     偏移 264
      [stval]    偏移 272
      [scause]   偏移 280
```

### CSR寄存器使用

| 寄存器 | 用途 | 读/写 |
|--------|------|-------|
| stvec  | Trap向量基地址 | 初始化时设置 |
| scause | 异常/中断原因 | 自动设置，读取判断类型 |
| sepc   | 异常程序计数器 | 自动设置，修改以跳过指令 |
| stval  | 异常相关值 | 自动设置（如_fault地址） |
| sstatus | 状态寄存器 | 控制中断使能 |
| sie    | 中断使能寄存器 | 使能特定中断类型 |
| sip    | 中断pending寄存器 | 清除软件中断 |
| time   | 时间计数器 | 读取当前时间 |

## 中断类型详解

### 1. 时钟中断 (SupervisorTimer, code=5)

**触发机制:**
```c
// 1. 设置定时器
sbi_set_timer(current_time + interval);

// 2. CPU时间超过设定值时触发中断

// 3. 处理函数
void handle_timer_interrupt() {
    timer_interrupt_count++;
    set_next_timer();  // 重新设置
}
```

**特点:**
- 周期性触发
- 用于时间管理和调度
- 可嵌套（允许其他中断打断）

### 2. 外部中断 (SupervisorExternal, code=9)

**模拟实现:**
```c
void simulate_uart_interrupt() {
    uart_interrupt_pending = 1;
    w_sip(r_sip() | (1 << 1));  // 触发软件中断
}
```

**真实硬件中:**
- UART控制器接收字符
- 产生IRQ信号
- 中断控制器转发到CPU

### 3. 软件中断 (SupervisorSoft, code=1)

**用途:**
- IPI (处理器间中断)
- 软件触发的异步事件
- 调试和测试

## 异常类型详解

### 异常分类

**同步异常 (Synchronous):**
由当前执行的指令直接引起
- Illegal Instruction
- Breakpoint (ebreak)
- Load/Store Access Fault
- Environment Call (ecall)

**特点:**
- 可预测
- stval包含详细信息
- 通常可以恢复

### 异常恢复策略

| 异常类型 | 恢复动作 | 说明 |
|---------|---------|------|
| Breakpoint | epc += 4 | 跳过ebreak继续执行 |
| Illegal Instruction | epc += 4 | 跳过非法指令 |
| Access Fault | epc += 4 | 跳过故障指令 |
| Misaligned | epc += 4 | 跳过未对齐访问 |
| Instruction Fault | panic | 无法恢复 |

## 中断嵌套机制

### 嵌套深度控制

```c
static volatile int interrupt_nesting = 0;

void handle_interrupt() {
    interrupt_nesting++;
    
    if (interrupt_nesting < 3) {
        enable_nested_interrupts();  // 允许更深嵌套
    }
    
    // ... 处理中断 ...
    
    interrupt_nesting--;
    disable_nested_interrupts();
}
```

### 嵌套场景示例

```
时间线:
T0: 主程序运行
T1: 时钟中断发生
    T2: 处理时钟中断 (nesting=1)
    T3: 允许嵌套
        T4: UART中断发生
            T5: 处理UART中断 (nesting=2)
        T6: UART中断返回
    T7: 时钟中断返回
T8: 主程序继续
```

### 栈安全考虑

**每层嵌套消耗:**
- trapframe: 288字节 (36 × 8)
- 函数调用开销: ~64字节
- 局部变量: ~128字节
- **总计: ~480字节/层**

**4KB栈空间支持:**
- 最大理论嵌套: 4096 / 480 ≈ 8层
- 实际限制: 3层 (保留安全余量)

## SBI接口

### 传统SBI调用 (Legacy)

```c
int sbi_call_legacy(enum sbi_call_type which, 
                    uint64 arg0, uint64 arg1, uint64 arg2);
```

**使用示例:**
```c
console_putchar('A');  // which=SBI_CONSOLE_PUTCHAR
shutdown();            // which=SBI_SHUTDOWN
```

### 扩展SBI调用 (Extension-based)

```c
struct sbiret sbi_call(long arg0, long arg1, long arg2, 
                       long arg3, long arg4, long arg5, 
                       long fid, long eid);
```

**TIME扩展:**
```c
// eid = 0x54494D45 ('TIME')
// fid = 0 (set_timer)
sbi_call(stime_value, 0, 0, 0, 0, 0, 0, SBI_EXT_TIME);
```

### SBI返回值

```c
struct sbiret {
    long error;  // 0=成功, 负数=错误码
    long value;  // 返回值
};
```

## 汇编宏详解

### save_all 宏

**功能:** 保存所有寄存器到栈

```assembly
.macro save_all  
    csrw sscratch, sp        # 临时保存sp
    addi sp, sp, -36*8       # 分配trapframe空间
    
    # 保存32个通用寄存器
    STORE x0, 0*8(sp)
    STORE x1, 1*8(sp)
    # ... (省略x2,稍后保存)
    STORE x31, 31*8(sp)
    
    # 保存CSR寄存器
    csrrw s0, sscratch, x0   # 恢复sp到s0
    csrr s1, sstatus
    csrr s2, sepc
    csrr s3, stval
    csrr s4, scause
    
    STORE s0, 2*8(sp)        # 保存sp
    STORE s1, 32*8(sp)       # 保存sstatus
    STORE s2, 33*8(sp)       # 保存sepc
    STORE s3, 34*8(sp)       # 保存stval
    STORE s4, 35*8(sp)       # 保存scause
.endm
```

### restore_all 宏

**功能:** 从栈恢复所有寄存器

```assembly
.macro restore_all 
    # 恢复CSR寄存器
    LOAD s1, 32*8(sp)
    LOAD s2, 33*8(sp)
    csrw sstatus, s1
    csrw sepc, s2
    
    # 恢复通用寄存器
    LOAD x1, 1*8(sp)
    # ... (省略x2)
    LOAD x31, 31*8(sp)
    
    # 最后恢复sp
    LOAD x2, 2*8(sp)
.endm
```

## 性能优化建议

### 1. 减少上下文保存开销

**当前实现:** 保存所有32个寄存器
**优化方案:** 只保存callee-saved寄存器
- 可减少约50%的保存开销
- 需要修改ABI约定

### 2. 快速路径处理

```c
// 对于常见中断（如timer），使用快速路径
if (cause == SupervisorTimer) {
    fast_timer_handler();
    return;
}
// 其他情况走慢速路径
slow_trap_handler();
```

### 3. 延迟中断处理

**Bottom-half机制:**
- Top-half: 最小化处理，关中断时间短
- Bottom-half: 详细处理，开中断执行

## 调试技巧

### 1. 查看trapframe

```c
void debug_trap(struct trapframe *tf) {
    printf("Cause: %lx\n", tf->cause);
    printf("EPC: %lx\n", tf->epc);
    printf("STVAL: %lx\n", tf->stval);
    print_regs(&tf->gpr);
}
```

### 2. 单步跟踪

在QEMU中使用:
```bash
qemu-system-riscv64 -machine virt -nographic \
  -kernel out/kernel.elf \
  -bios rustsbi-qemu.bin \
  -S -s  # 等待GDB连接

# 另一个终端
gdb-multiarch out/kernel.elf
(gdb) target remote localhost:1234
(gdb) break trap_vector
(gdb) continue
```

### 3. 日志级别

```c
#define LOG_LEVEL_INFO  1
#define LOG_LEVEL_DEBUG 2

#if LOG_LEVEL >= LOG_LEVEL_DEBUG
#define DBG_PRINTF(...) printf(__VA_ARGS__)
#else
#define DBG_PRINTF(...)
#endif
```

## 扩展方向

### 1. 添加更多设备中断
- VirtIO块设备
- 网络接口
- GPIO中断

### 2. 实现中断亲和性
- 将特定中断绑定到特定CPU核心
- 负载均衡

### 3. 中断统计和 profiling
- 记录每个中断的处理时间
- 生成中断频率报告

### 4. 动态中断路由
- 运行时修改中断处理函数
- 插件式中断处理框架