#!/bin/bash
# 脚本功能：编译内核并通过 QEMU 运行，支持清理、调试等选项

# 定义变量
BUILDDIR="out"          # 编译输出目录
KERNEL_ELF="${BUILDDIR}/kernel.elf"  # 内核 ELF 文件路径
BOOTLOADER="lib/rustsbi-qemu/rustsbi-qemu.bin"  # SBI 固件路径

# 帮助信息
usage() {
    echo "用法: $0 [选项]"
    echo "选项:"
    echo "  run      编译并运行内核（默认）"
    echo "  build    仅编译内核"
    echo "  clean    清理编译产物"
    echo "  debug    编译并启动调试模式（QEMU + GDB）"
    echo "  help     显示帮助信息"
    exit 1
}

# 编译内核
build_kernel() {
    echo "=== 开始编译内核 ==="
    # 检查 Makefile 是否存在
    if [ ! -f "Makefile" ]; then
        echo "错误：未找到 Makefile"
        exit 1
    fi
    # 执行 make 编译
    make build || {
        echo "=== 编译失败 ==="
        exit 1
    }
    echo "=== 编译完成 ==="
}

# 运行内核
run_kernel() {
    # 先编译（确保最新）
    build_kernel
    # 检查内核文件是否存在
    if [ ! -f "${KERNEL_ELF}" ]; then
        echo "错误：未找到内核文件 ${KERNEL_ELF}"
        exit 1
    fi
    echo "=== 启动内核 ==="
    # 通过 QEMU 运行（无图形界面，退出按 Ctrl+A 再按 X）
    qemu-system-riscv64 \
        -machine virt \
        -nographic \
        -bios "${BOOTLOADER}" \
        -kernel "${KERNEL_ELF}"
}

# 清理编译产物
clean_kernel() {
    echo "=== 清理编译产物 ==="
    if [ -d "${BUILDDIR}" ]; then
        make clean || {
            echo "警告：清理失败，手动删除 ${BUILDDIR}"
            rm -rf "${BUILDDIR}"
        }
    fi
    echo "=== 清理完成 ==="
}

# 调试模式（QEMU + GDB）
debug_kernel() {
    build_kernel
    if [ ! -f "${KERNEL_ELF}" ]; then
        echo "错误：未找到内核文件 ${KERNEL_ELF}"
        exit 1
    fi
    echo "=== 启动调试模式（QEMU + GDB） ==="
    echo "提示：在另一个终端执行 riscv64-unknown-elf-gdb ${KERNEL_ELF}，然后输入 target remote :1234"
    # QEMU 监听 1234 端口，等待 GDB 连接
    qemu-system-riscv64 \
        -machine virt \
        -nographic \
        -bios "${BOOTLOADER}" \
        -kernel "${KERNEL_ELF}" \
        -s -S  # -s 等价于 -gdb tcp::1234，-S 表示启动后暂停
}

# 解析命令行参数
case "$1" in
    run)
        run_kernel
        ;;
    build)
        build_kernel
        ;;
    clean)
        clean_kernel
        ;;
    debug)
        debug_kernel
        ;;
    help)
        usage
        ;;
    *)
        # 默认执行 run
        run_kernel
        ;;
esac