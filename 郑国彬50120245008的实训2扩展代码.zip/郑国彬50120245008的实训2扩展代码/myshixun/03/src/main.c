#include "print.h"
#include "trap.h"

// 任务1：补充实现trap_test()函数，触发异常并打印提示
void trap_test() {
    /* 请打印即将执行的非法操作提示："*(int *)0x00000000 = 100\n" */
    printf("*(int *)0x00000000 = 100\n");

    /*
     * Synchronous exception code = 7
     * Store/AMO access fault
     */
    /* 请执行非法内存写入操作，触发存储访问错误异常 */
    *(int *)0x00000000 = 100;

    /* 请打印异常返回后的提示："Yeah! I'm return back from trap!\n" */
    printf("Yeah! I'm return back from trap!\n");
}


// 任务2：补充实现test_interrupts()函数，调用测试并打印流程
void test_interrupts() {
    /* 请打印测试开始提示："Testing interrupts...\n" */
    printf("Testing interrupts...\n");

    /* 请调用trap_test()函数，触发异常测试 */
    trap_test();

    /* 请打印测试结束提示："Interrupt test completed.\n" */
    printf("Interrupt test completed.\n");
}


// 任务3：完善main()函数，完成初始化与测试调用
void main(void) {
    /* 请打印程序启动提示1："RISC-V Bootloader\n" */
    printf("RISC-V Bootloader\n");

    /* 请打印程序启动提示2："Hello XOS!\n" */
    printf("Hello XOS!\n");

    // 初始化中断处理
    /* 请调用init_interrupt()函数，初始化中断环境 */
    init_interrupt();

    // 测试中断
    /* 请调用test_interrupts()函数，启动异常与中断测试 */
    test_interrupts();

    // 进入无限循环
    /* 请补充while(1)无限循环，防止程序退出 */
    while (1) {
        // 无限循环
    }
}