#ifndef XOS_04_SBI_H
#define XOS_04_SBI_H

void console_putchar(int);
int console_getchar(void);
void shutdown(void);

#endif
