#ifndef PLIC_H
#define PLIC_H

#include "types.h"

#define UART0_IRQ 10

void plic_init(void);
uint32 plic_claim(void);
void plic_complete(uint32 irq);
void uart_irq_init(void);
void uart_demo_xmit_irq(void);
void uart_external_irq_loop(int rounds);
void uart_irq_stop(void);

#endif
