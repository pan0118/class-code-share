#include "defs.h"
#include "plic.h"

#define PLIC 0x0c000000UL
#define PLIC_PRIORITY(id) (PLIC + (uintptr)(id) * 4)
#define PLIC_SENABLE(hart) (PLIC + 0x2080UL + (hart) * 0x100UL)
#define PLIC_SPRIORITY(hart) (PLIC + 0x201000UL + (hart) * 0x2000UL)
#define PLIC_SCLAIM(hart) (PLIC + 0x201004UL + (hart) * 0x2000UL)

#define UART0 0x10000000UL

void plic_init(void)
{
	const int hart = 0;

	*(volatile uint32 *)PLIC_PRIORITY(UART0_IRQ) = 1;
	*(volatile uint32 *)PLIC_SENABLE(hart) = (1U << UART0_IRQ);
	*(volatile uint32 *)PLIC_SPRIORITY(hart) = 0;
}

uint32 plic_claim(void)
{
	return *(volatile uint32 *)PLIC_SCLAIM(0);
}

void plic_complete(uint32 irq)
{
	*(volatile uint32 *)PLIC_SCLAIM(0) = irq;
}

/* 关闭 UART 全部中断并清 pending，避免 THRE 风暴或与 SBI 控制台复用串口时 ISR 里 printf 乱码 */
void uart_irq_stop(void)
{
	volatile uint8 *u = (volatile uint8 *)UART0;
	int i;

	*(u + 1) = 0;
	for (i = 0; i < 4; i++)
		(void)*(u + 2);
	while ((*(u + 5)) & 0x01)
		(void)*u;
	(void)*(u + 5);
}

void uart_irq_init(void)
{
	uart_irq_stop();
}

/*
 * 报告演示：打开 THR empty 中断并写发送保持寄存器，便于在无键盘输入时仍产生 UART IRQ（QEMU virt 常见）。
 */
void uart_demo_xmit_irq(void)
{
	*(volatile uint8 *)(UART0 + 1) = 0x03; /* bit0 RDAI + bit1 THREI */
	*(volatile uint8 *)UART0 = 'R';
	*(volatile uint8 *)UART0 = 'E';
	*(volatile uint8 *)UART0 = 'P';
	for (volatile int j = 0; j < 2000000; j++)
		;
	*(volatile uint8 *)(UART0 + 1) = 0x01;
}

void uart_external_irq_loop(int rounds)
{
	volatile uint8 *uart = (volatile uint8 *)UART0;
	int r;

	if (rounds < 1)
		rounds = 1;
	if (rounds > 32)
		rounds = 32;

	*(uart + 1) = 0x03;
	for (r = 1; r <= rounds; r++) {
		printf("[MAIN][UART] 第 %d/%d 次写 THR -> 期待 PLIC UART 外部中断\n", r,
		       rounds);
		*uart = (uint8)('0' + (r % 10));
		for (volatile int k = 0; k < 1200000; k++)
			;
	}
	uart_irq_stop();
	print_string("[MAIN][UART] 循环触发结束（已 uart_irq_stop 止血）\n");
}
