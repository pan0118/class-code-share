#include "print.h"
#include "xos_04_sbi.h"
#include "types.h"
#include <stdarg.h>

void print_string(const char *str) {
    while (*str) {
        print_char(*str++);
    }
}

void print_char(char c) {
    console_putchar(c);
}

static char digits[] = "0123456789abcdef";

static void printint(int xx, int base, int sign)
{
	char buf[16];
	int i;
	uint x;

	if (sign && (sign = xx < 0))
		x = -xx;
	else
		x = xx;

	i = 0;
	do {
		buf[i++] = digits[x % base];
	} while ((x /= base) != 0);

	if (sign)
		buf[i++] = '-';

	while (--i >= 0)
		print_char(buf[i]);
}

static void printptr(uint64 x)
{
	int i;
	print_char('0');
	print_char('x');
	for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
		print_char(digits[x >> (sizeof(uint64) * 8 - 4)]);
}

static void print_u32_dec(unsigned int n)
{
	char tmp[12];
	int i = 0;

	if (n == 0) {
		print_char('0');
		return;
	}
	while (n) {
		tmp[i++] = digits[n % 10U];
		n /= 10U;
	}
	while (i > 0)
		print_char(tmp[--i]);
}

static void print_u64_dec(uint64 n)
{
	char tmp[24];
	int i = 0;

	if (n == 0) {
		print_char('0');
		return;
	}
	while (n) {
		tmp[i++] = digits[n % 10ULL];
		n /= 10ULL;
	}
	while (i > 0)
		print_char(tmp[--i]);
}

/* 支持: %d %x(32位int) %u(32位无符号) %s %% %p %llu %llx */
void printf(char *fmt, ...)
{
	va_list ap;
	int i, c;
	char *s;

	if (fmt == 0)
		panic("null fmt");

	va_start(ap, fmt);
	for (i = 0; (c = fmt[i] & 0xff) != 0; i++) {
		if (c != '%') {
			print_char(c);
			continue;
		}
		c = fmt[++i] & 0xff;
		if (c == 0)
			break;

		if (c == 'l' && (fmt[i + 1] & 0xff) == 'l') {
			/* i 指向第一个 'l'；跳过 "ll" 后 i 落在 'u' 或 'x' 上，勿再 ++ */
			i += 2;
			c = fmt[i] & 0xff;
			if (c == 'u') {
				print_u64_dec(va_arg(ap, uint64));
				continue;
			}
			if (c == 'x') {
				printptr(va_arg(ap, uint64));
				continue;
			}
			print_char('%');
			print_char('l');
			print_char('l');
			if (c)
				print_char(c);
			continue;
		}

		switch (c) {
		case 'd':
			printint(va_arg(ap, int), 10, 1);
			break;
		case 'u':
			print_u32_dec(va_arg(ap, unsigned int));
			break;
		case 'x':
			printint(va_arg(ap, int), 16, 1);
			break;
		case 'p':
			printptr(va_arg(ap, uint64));
			break;
		case 's':
			if ((s = va_arg(ap, char *)) == 0)
				s = "(null)";
			for (; *s; s++)
				print_char(*s);
			break;
		case '%':
			print_char('%');
			break;
		default:
			print_char('%');
			print_char(c);
			break;
		}
	}
	va_end(ap);
}


void panic(char *s)
{
	printf("panic: %s\n", s);
	while (1) {
	}
}


