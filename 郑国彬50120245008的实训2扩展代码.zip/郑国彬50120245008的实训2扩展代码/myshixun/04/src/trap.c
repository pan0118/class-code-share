#include "defs.h"
#include "trap.h"
#include "plic.h"

extern void trap_vector(void);

/* 测试用：若非 0，异常返回时跳转到该 PC，而不是 epc+4 */
uintptr trap_recover_epc;

#define TIMER_DELTA (10ULL * 1000ULL * 1000ULL) /* QEMU time 常约 10MHz → 约 1s 一次 */

volatile uint64 clock_ticks;
volatile int timer_irq_count;
volatile int ext_irq_count;
volatile int nested_timer_fired_in_ext;

static int trap_irq_depth;
static volatile int g_timer_irq_print_budget;

static const char *exception_name(uint64 code)
{
	switch (code) {
	case InstructionMisaligned:
		return "Instruction Misaligned / 指令地址未对齐";
	case InstructionAccessFault:
		return "Instruction Access Fault / 指令访问故障";
	case IllegalInstruction:
		return "Illegal Instruction / 非法指令";
	case Breakpoint:
		return "Breakpoint / 断点";
	case LoadMisaligned:
		return "Load Misaligned / 加载地址未对齐";
	case LoadAccessFault:
		return "Load Access Fault / 加载访问故障";
	case StoreMisaligned:
		return "Store Misaligned / 存储地址未对齐";
	case StoreAccessFault:
		return "Store Access Fault / 存储访问故障";
	case UserEnvCall:
		return "User Environment Call";
	case SupervisorEnvCall:
		return "Supervisor Environment Call";
	case MachineEnvCall:
		return "Machine Environment Call";
	case InstructionPageFault:
		return "Instruction Page Fault";
	case LoadPageFault:
		return "Load Page Fault";
	case StorePageFault:
		return "Store Page Fault";
	default:
		return "Unknown exception";
	}
}

static void clock_schedule_next(void)
{
	sbi_set_timer(r_time() + TIMER_DELTA);
}

void trap_timer_rearm(void)
{
	clock_schedule_next();
}

void trap_timer_irq_off(void)
{
	w_sie(r_sie() & ~SIE_STIE);
}

void trap_timer_report_lines(int lines)
{
	g_timer_irq_print_budget = lines;
}

void kernel_trap_init(void)
{
	w_stvec(((uint64)trap_vector) & ~0x3UL);
	w_sie(r_sie() | SIE_SSIE | SIE_STIE | SIE_SEIE);
}

void init_interrupt(void)
{
	kernel_trap_init();
	plic_init();
	uart_irq_init();
	clock_schedule_next();
}

void print_trapframe(struct trapframe *tf)
{
	printf("trapframe at %p\n", (uint64)(uintptr)tf);
	print_regs(&tf->gpr);
	printf("  status   %llx\n", (uint64)tf->status);
	printf("  epc      %llx\n", (uint64)tf->epc);
	printf("  stval    %llx\n", (uint64)tf->stval);
	printf("  cause    %llx\n", (uint64)tf->cause);
}

void print_csr(struct trapframe *tf)
{
	printf("  status   %llx\n", (uint64)tf->status);
	printf("  epc      %llx\n", (uint64)tf->epc);
	printf("  stval    %llx\n", (uint64)tf->stval);
	printf("  cause    %llx\n", (uint64)tf->cause);
}

void print_regs(struct pushregs *gpr)
{
	printf("  zero     %llx\n", (uint64)gpr->zero);
	printf("  ra       %llx\n", (uint64)gpr->ra);
	printf("  sp       %llx\n", (uint64)gpr->sp);
	printf("  gp       %llx\n", (uint64)gpr->gp);
	printf("  tp       %llx\n", (uint64)gpr->tp);
	printf("  t0       %llx\n", (uint64)gpr->t0);
	printf("  t1       %llx\n", (uint64)gpr->t1);
	printf("  t2       %llx\n", (uint64)gpr->t2);
	printf("  s0       %llx\n", (uint64)gpr->s0);
	printf("  s1       %llx\n", (uint64)gpr->s1);
	printf("  a0       %llx\n", (uint64)gpr->a0);
	printf("  a1       %llx\n", (uint64)gpr->a1);
	printf("  a2       %llx\n", (uint64)gpr->a2);
	printf("  a3       %llx\n", (uint64)gpr->a3);
	printf("  a4       %llx\n", (uint64)gpr->a4);
	printf("  a5       %llx\n", (uint64)gpr->a5);
	printf("  a6       %llx\n", (uint64)gpr->a6);
	printf("  a7       %llx\n", (uint64)gpr->a7);
	printf("  s2       %llx\n", (uint64)gpr->s2);
	printf("  s3       %llx\n", (uint64)gpr->s3);
	printf("  s4       %llx\n", (uint64)gpr->s4);
	printf("  s5       %llx\n", (uint64)gpr->s5);
	printf("  s6       %llx\n", (uint64)gpr->s6);
	printf("  s7       %llx\n", (uint64)gpr->s7);
	printf("  s8       %llx\n", (uint64)gpr->s8);
	printf("  s9       %llx\n", (uint64)gpr->s9);
	printf("  s10      %llx\n", (uint64)gpr->s10);
	printf("  s11      %llx\n", (uint64)gpr->s11);
	printf("  t3       %llx\n", (uint64)gpr->t3);
	printf("  t4       %llx\n", (uint64)gpr->t4);
	printf("  t5       %llx\n", (uint64)gpr->t5);
	printf("  t6       %llx\n", (uint64)gpr->t6);
}

/*
 * 中断优先级（数值越大优先级越高）：
 *   SupervisorTimer > SupervisorExternal > SupervisorSoft/UserSoft
 * 嵌套：在外部中断处理中临时只打开 STIE，使时钟中断可抢占 UART/PLIC 外部中断。
 */
void handle_interrupt(struct trapframe *tf)
{
	uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;

	trap_irq_depth++;

	switch (cause_code) {
	case UserSoft:
		printf("UserSoft interrupt!\n");
		break;

	case SupervisorSoft:
		printf("SupervisorSoft interrupt / 软件中断\n");
		w_sip(r_sip() & ~(1UL << 1));
		break;

	case SupervisorTimer:
		timer_irq_count++;
		if (trap_irq_depth > 1)
			nested_timer_fired_in_ext++;
		clock_ticks++;
		if (g_timer_irq_print_budget > 0) {
			printf("[Clock IRQ] tick=%llu\n",
			       (unsigned long long)clock_ticks);
			g_timer_irq_print_budget--;
		}
		clock_schedule_next();
		break;

	case SupervisorExternal: {
		uint32 irq = plic_claim();

		if (irq == UART0_IRQ) {
			ext_irq_count++;
			(void)*(volatile uint8 *)(0x10000000UL + 2);
			while ((*(volatile uint8 *)(0x10000000UL + 5)) & 0x01)
				(void)*(volatile uint8 *)0x10000000UL;
		} else if (irq != 0) {
			printf("[ISR][EXT] PLIC claim=%d (non-UART)\n", (int)irq);
		}

		/* 仅允许更高优先级的时钟中断嵌套进入 */
		{
			uint64 sie_saved = r_sie();

			w_sie(SIE_STIE);
			intr_on();
			for (volatile int i = 0; i < 400000; i++)
				;
			intr_off();
			w_sie(sie_saved);
		}

		if (irq)
			plic_complete(irq);
		break;
	}

	default:
		printf("Unknown interrupt! Code = %llu\n",
		       (unsigned long long)cause_code);
		break;
	}

	trap_irq_depth--;
}

void handle_exception(struct trapframe *tf)
{
	uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;

	printf("Exception occurred! %s (cause=%d)\n", exception_name(cause_code),
	       (int)cause_code);
	print_csr(tf);

	if (trap_recover_epc) {
		tf->epc = trap_recover_epc;
		trap_recover_epc = 0;
	} else {
		tf->epc += 4;
	}
}

static inline void trap_handler(struct trapframe *tf)
{
	if (tf->cause & SCAUSE_MASK_INTERRUPT) {
		handle_interrupt(tf);
	} else {
		handle_exception(tf);
	}
}

void trap(struct trapframe *tf)
{
	trap_handler(tf);
}

void test_soft_interrupt_trigger(void)
{
	w_sip(r_sip() | (1UL << 1));
}
