#include "xos_04_sbi.h"
#include "types.h"

/*
 * RustSBI-QEMU 0.1.1 固件：定时器用 Legacy SBI（a7=0, a0=绝对 time 值）。
 * SBI v1.0 TIME 扩展（EID "TIME"）在部分环境也可用，此处优先 Legacy 以兼容实验镜像。
 */
void sbi_set_timer(uint64 stime_value)
{
	register uint64 a0 asm("a0") = stime_value;
	register uint64 a1 asm("a1") = 0;
	register uint64 a2 asm("a2") = 0;
	register uint64 a7 asm("a7") = 0; /* Legacy: extension 0 = set_timer */
	asm volatile("ecall" : : "r"(a0), "r"(a1), "r"(a2), "r"(a7) : "memory");
}

enum sbi_call_type {
	SBI_SET_TIMER = 0,
	SBI_CONSOLE_PUTCHAR = 1,
	SBI_CONSOLE_GETCHAR = 2,
	SBI_CLEAR_IPI = 3,
	SBI_SEND_IPI = 4,
	SBI_REMOTE_FENCE_I = 5,
	SBI_REMOTE_SFENCE_VMA = 6,
	SBI_REMOTE_SFENCE_VMA_ASID = 7,
	SBI_SHUTDOWN = 8
};

static inline int sbi_call(enum sbi_call_type which, uint64 arg0, uint64 arg1,
			   uint64 arg2)
{
	register uint64 a0 asm("a0") = arg0;
	register uint64 a1 asm("a1") = arg1;
	register uint64 a2 asm("a2") = arg2;
	register uint64 a7 asm("a7") = which;
	int ret;
	asm volatile("ecall"
		     : "=r"(ret)
		     : "r"(a0), "r"(a1), "r"(a2), "r"(a7)
		     : "memory");
	if (ret < 0)
		return -1;
	return ret;
}

void console_putchar(int c)
{
	(void)sbi_call(SBI_CONSOLE_PUTCHAR, (uint64)c, 0, 0);
}

int console_getchar(void)
{
	return sbi_call(SBI_CONSOLE_GETCHAR, 0, 0, 0);
}

void shutdown(void)
{
	(void)sbi_call(SBI_SHUTDOWN, 0, 0, 0);
}
