#include "print.h"
#include "trap.h"
#include "riscv.h"
#include "plic.h"

/* QEMU virt 上 time 频率常见为 10MHz，用于“截图停顿”近似秒级等待 */
#define REPORT_TIME_HZ 10000000ULL

static void report_pause_sec(int sec)
{
	uint64 t0 = r_time();
	uint64 until = t0 + (uint64)sec * REPORT_TIME_HZ;

	printf("(停顿约 %d 秒，便于截图；基于 time~10MHz)\n", sec);
	while (r_time() < until)
		;
}

static void report_banner(const char *id, const char *title)
{
	print_string("\n");
	print_string("============================================================\n");
	printf("[报告小节 %s] %s\n", id, title);
	print_string("============================================================\n");
}

static void report_shot(const char *hint)
{
	printf(">>> 截图建议: %s <<<\n", hint);
}

static void test_illegal_instruction(void)
{
	printf("  [用例] 非法指令 .word 0xFFFFFFFF\n");
	trap_recover_epc = (uintptr)&&done;
	asm volatile(".word 0xffffffff");
done:
	trap_recover_epc = 0;
	printf("  [结果] 已从 trap 返回\n");
}

static void test_breakpoint(void)
{
	printf("  [用例] ebreak 断点\n");
	trap_recover_epc = (uintptr)&&done;
	asm volatile("ebreak");
done:
	trap_recover_epc = 0;
	printf("  [结果] 已从 trap 返回\n");
}

static void test_load_misaligned(void)
{
	printf("  [用例] lw from addr 1 (QEMU 常报 AccessFault 而非 Misaligned)\n");
	trap_recover_epc = (uintptr)&&done;
	asm volatile("lw zero, 1(zero)");
done:
	trap_recover_epc = 0;
	printf("  [结果] 已从 trap 返回\n");
}

static void test_store_misaligned(void)
{
	printf("  [用例] sw to addr 1\n");
	trap_recover_epc = (uintptr)&&done;
	asm volatile("sw zero, 1(zero)");
done:
	trap_recover_epc = 0;
	printf("  [结果] 已从 trap 返回\n");
}

static void test_load_access_fault(void)
{
	printf("  [用例] lw from 0\n");
	trap_recover_epc = (uintptr)&&done;
	asm volatile("lw zero, 0(zero)");
done:
	trap_recover_epc = 0;
	printf("  [结果] 已从 trap 返回\n");
}

static void test_store_access_fault(void)
{
	printf("  [用例] store to 0\n");
	trap_recover_epc = (uintptr)&&done;
	*(volatile int *)0x00000000 = 100;
done:
	trap_recover_epc = 0;
	printf("  [结果] 已从 trap 返回\n");
}

static void test_instruction_access_fault(void)
{
	void (*f)(void) = (void (*)(void))0x90000000UL;

	printf("  [用例] 跳转到未映射 0x90000000\n");
	trap_recover_epc = (uintptr)&&done;
	f();
done:
	trap_recover_epc = 0;
	printf("  [结果] 已从 trap 返回\n");
}

static void test_instruction_misaligned(void)
{
	printf("  [用例] jr 到 32-bit 指令中间 (QEMU 或报 Illegal)\n");
	trap_recover_epc = (uintptr)&&done;
	asm volatile(
		".option push\n"
		".option norvc\n"
		"la t0, 1f\n"
		"addi t0, t0, 2\n"
		"jr t0\n"
		"1:\n"
		"nop\n"
		".option pop\n");
done:
	trap_recover_epc = 0;
	printf("  [结果] 已从 trap 返回\n");
}

void run_exception_tests(void)
{
	report_banner("1", "扩展：同步异常 / scause + CSR 打印 + 安全返回");
	report_shot("整节一张图：多种异常与 CSR 行");

	test_illegal_instruction();
	test_breakpoint();
	test_load_misaligned();
	test_store_misaligned();
	test_load_access_fault();
	test_store_access_fault();
	test_instruction_access_fault();
	test_instruction_misaligned();

	printf("[小节1 结论] 已覆盖非法指令/断点/访问错/取指错等；具体 cause 以 QEMU 为准。\n");
	report_pause_sec(2);
}

void run_interrupt_tests(void)
{
	report_banner("2", "扩展：Supervisor 软件中断 (SSIP)");
	report_shot("含一行 SupervisorSoft interrupt 即可截图");
	trap_timer_irq_off();
	test_soft_interrupt_trigger();
	report_pause_sec(1);

	report_banner("3", "扩展：时钟中断 (SupervisorTimer)");
	report_shot("含 [Clock IRQ] 行 + 末尾计数");
	w_sie(r_sie() | SIE_STIE);
	trap_timer_rearm();
	trap_timer_report_lines(4);
	printf("等待约 5s 以收集定时器 tick...\n");
	report_pause_sec(5);
	printf("timer_irq_count=%d  clock_ticks=%llu\n", timer_irq_count,
	       (unsigned long long)clock_ticks);
	trap_timer_irq_off();
	report_pause_sec(1);

	report_banner("4", "扩展：外部中断 / UART 模拟 — 循环触发 + 静默 ISR 计数");
	report_shot("多行 [MAIN][UART]；ISR 内不再 printf（与 SBI 控制台同 UART 会乱码）；看 ext_irq_count 增加");
	trap_timer_irq_off();
	/* 仅外部中断，避免与时钟输出交织 */
	w_sie(SIE_SEIE);
	printf("ext_irq_count(before loop)=%d\n", ext_irq_count);
	uart_external_irq_loop(10);
	printf("ext_irq_count(after loop)=%d（THRE 可能一写多中断，属正常；已 uart_irq_stop）\n",
	       ext_irq_count);
	/* 小节 5–6 不需要外部中断：关 SEIE，避免 wfi 仍被 UART 唤醒 */
	w_sie(SIE_SSIE | SIE_STIE);
	report_pause_sec(1);

	report_banner("5", "扩展：中断优先级与嵌套（说明 + 统计）");
	report_shot("含 nested_timer_fired_in_ext 说明；若 UART 节曾进外部 ISR 且窗内发生时钟则可能 >0");
	printf("nested_timer_fired_in_ext=%d\n", nested_timer_fired_in_ext);
	printf("设计要点: 外部 ISR 内 temporarily 仅开 STIE + intr_on，定时器可嵌套。\n");
	report_pause_sec(1);

	report_banner("6", "汇总表（报告末尾一张图）");
	printf("+---------------------------+--------+\n");
	printf("| 项                        | 状态   |\n");
	printf("+---------------------------+--------+\n");
	printf("| 同步异常 trap+CSR         | OK     |\n");
	printf("| 软件中断 SSIP             | OK     |\n");
	printf("| 时钟中断 (计数>0)         | %s |\n",
	       timer_irq_count > 0 ? "OK    " : "CHECK ");
	printf("| UART/PLIC 外部 (计数增加) | %s |\n",
	       ext_irq_count > 0 ? "OK    " : "CHECK ");
	printf("| 嵌套统计 nested>0         | %s |\n",
	       nested_timer_fired_in_ext > 0 ? "OK    " : "OPTIONAL");
	printf("+---------------------------+--------+\n");
	printf("CHECK=若本机 QEMU 行为不同，请在报告中写明现象与原因。\n");

	trap_timer_irq_off();
	uart_irq_stop();
	w_sie(r_sie() & ~(uint64)SIE_SEIE);
	print_string("\n========== 报告用例全部结束 ==========\n\n");
}

static void trap_test(void)
{
	printf("*(int *)0x00000000 = 100\n");
	trap_recover_epc = (uintptr)&&done;
	*(int *)0x00000000 = 100;
done:
	trap_recover_epc = 0;
	print_string("Yeah! I'm return back from trap!\n");
}

static void test_interrupts(void)
{
	report_banner("1b", "回归：Store Access Fault (trap_test)");
	report_shot("异常返回后打印 Yeah");
	print_string("Testing interrupts...\n");
	trap_test();
	print_string("Interrupt test completed.\n");
	report_pause_sec(1);
}

void main(void)
{
	print_string("RISC-V Bootloader\n");
	print_string("Hello XOS!\n");
	printf("\n######## Lab04 验证报告输出（按小节截图）########\n\n");

	init_interrupt();

	intr_off();
	run_exception_tests();
	intr_on();

	test_interrupts();
	run_interrupt_tests();

	uart_irq_stop();
	w_sie(r_sie() & ~(uint64)SIE_SEIE);
	trap_timer_irq_off();

	while (1) {
		asm volatile("wfi");
	}
}
