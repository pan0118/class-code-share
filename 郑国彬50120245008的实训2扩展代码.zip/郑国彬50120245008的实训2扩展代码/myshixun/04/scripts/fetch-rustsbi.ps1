# 若缺少 RustSBI 固件，下载到 lib/rustsbi-qemu/rustsbi-qemu.bin
$ErrorActionPreference = "Stop"
# 本脚本位于 myshixun/04/scripts/，工程根为上一级
$root = Split-Path -Parent $PSScriptRoot
$outDir = Join-Path $root "lib\rustsbi-qemu"
$bin = Join-Path $outDir "rustsbi-qemu.bin"
if (Test-Path $bin) {
	Write-Host "已存在: $bin"
	exit 0
}
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$zip = Join-Path $env:TEMP "rustsbi-qemu-release.zip"
$uri = "https://github.com/rustsbi/rustsbi-qemu/releases/download/v0.1.1/rustsbi-qemu-release.zip"
Write-Host "下载: $uri"
Invoke-WebRequest -Uri $uri -OutFile $zip -UseBasicParsing
$extract = Join-Path $env:TEMP "rustsbi-extract-$(Get-Random)"
Expand-Archive -Path $zip -DestinationPath $extract -Force
$found = Get-ChildItem -Path $extract -Filter "rustsbi-qemu.bin" -Recurse | Select-Object -First 1
if (-not $found) { throw "zip 内未找到 rustsbi-qemu.bin" }
Copy-Item -Force $found.FullName $bin
Remove-Item -Recurse -Force $extract -ErrorAction SilentlyContinue
Write-Host "已写入: $bin"
