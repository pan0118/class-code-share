#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
docker build -t myshixun04-riscv -f "$ROOT/Dockerfile" "$ROOT"
docker run --rm -it -v "$ROOT:/work" -w /work myshixun04-riscv
