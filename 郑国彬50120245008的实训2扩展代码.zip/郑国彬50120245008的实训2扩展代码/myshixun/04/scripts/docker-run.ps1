# 使用 Docker 在 Ubuntu 环境中 make + 短时运行 QEMU（需安装 Docker Desktop 并启动引擎）
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
	Write-Error "未找到 docker。请先安装 Docker Desktop: https://docs.docker.com/desktop/setup/install/windows-install/"
	exit 1
}

& "$PSScriptRoot\fetch-rustsbi.ps1"

$tag = "myshixun04-riscv"
Write-Host "构建镜像 $tag ..."
docker build -t $tag -f "$root\Dockerfile" $root

Write-Host "编译并运行 QEMU（约 45 秒后自动结束）..."
docker run --rm -it -v "${root}:/work" -w /work $tag
