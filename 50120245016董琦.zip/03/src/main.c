#include "print.h"
#include "trap.h"

// 任务1：补充实现trap_test()函数，触发异常并打印提示
void trap_test(){
    /* 打印即将执行的非法操作提示 */
    printf("*(int *)0x00000000 = 100\n");

	/*
	 * Synchronous exception code = 7
	 * Store/AMO access fault
	 */
	/* 执行非法内存写入操作，触发存储访问错误异常 */
	*(int *)0x00000000 = 100;
	
	/* 打印异常返回后的提示 */
	printf("Yeah! I'm return back from trap!\n");
}

// 任务2：补充实现test_interrupts()函数，调用测试并打印流程
void test_interrupts() {
    /* 打印测试开始提示 */
    printf("Testing interrupts...\n");
    
    /* 调用trap_test()函数，触发异常测试 */
    trap_test();
    
    /* 打印测试结束提示 */
    printf("Interrupt test completed.\n");
}

// 任务3：完善main()函数，完成初始化与测试调用
void main(void) {
    /* 打印程序启动提示 */
    printf("RISC-V Bootloader\n");
    printf("Hello XOS!\n");

    // 初始化中断处理
    init_interrupt();

    // 测试中断
    test_interrupts();

    // 进入无限循环，防止程序退出
    while(1) {
        // 无限循环
    }
}