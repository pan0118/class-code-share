#include "defs.h"

#include "trap.h"

extern void trap_vector();

//在以下部分写出完成任务的代码，初始化向量表 + 编写 w_stvec () 函数并定义 trap_vector 标签，与第一关任务代码一致
/*********Begin*********/
void kernel_trap_init() {
  w_stvec((uint64) trap_vector);
  intr_on();
}

void init_interrupt() {
  kernel_trap_init();
}

/*********End**********/

void print_trapframe(struct trapframe * tf) {
  printf("trapframe at %p\n", tf);
  print_regs( & tf - > gpr);
  printf("  status   0x%08x\n", tf - > status);
  printf("  epc      0x%08x\n", tf - > epc);
  printf("  stval   0x%08x\n", tf - > stval);
  printf("  cause    0x%08x\n", tf - > cause);
}

void print_csr(struct trapframe * tf) {
  printf("  status   0x%x\n", tf - > status);
  printf("  epc      0x%x\n", tf - > epc);
  printf("  stval   0x%x\n", tf - > stval);
  printf("  cause    0x%x\n", tf - > cause);
}
void print_regs(struct pushregs * gpr) {
  printf("  zero     0x%x\n", gpr - > zero);
  printf("  ra       0x%x\n", gpr - > ra);
  printf("  sp       0x%x\n", gpr - > sp);
  printf("  gp       0x%x\n", gpr - > gp);
  printf("  tp       0x%x\n", gpr - > tp);
  printf("  t0       0x%x\n", gpr - > t0);
  printf("  t1       0x%x\n", gpr - > t1);
  printf("  t2       0x%x\n", gpr - > t2);
  printf("  s0       0x%x\n", gpr - > s0);
  printf("  s1       0x%x\n", gpr - > s1);
  printf("  a0       0x%x\n", gpr - > a0);
  printf("  a1       0x%x\n", gpr - > a1);
  printf("  a2       0x%x\n", gpr - > a2);
  printf("  a3       0x%x\n", gpr - > a3);
  printf("  a4       0x%x\n", gpr - > a4);
  printf("  a5       0x%x\n", gpr - > a5);
  printf("  a6       0x%x\n", gpr - > a6);
  printf("  a7       0x%x\n", gpr - > a7);
  printf("  s2       0x%x\n", gpr - > s2);
  printf("  s3       0x%x\n", gpr - > s3);
  printf("  s4       0x%x\n", gpr - > s4);
  printf("  s5       0x%x\n", gpr - > s5);
  printf("  s6       0x%x\n", gpr - > s6);
  printf("  s7       0x%x\n", gpr - > s7);
  printf("  s8       0x%x\n", gpr - > s8);
  printf("  s9       0x%x\n", gpr - > s9);
  printf("  s10      0x%x\n", gpr - > s10);
  printf("  s11      0x%x\n", gpr - > s11);
  printf("  t3       0x%x\n", gpr - > t3);
  printf("  t4       0x%x\n", gpr - > t4);
  printf("  t5       0x%x\n", gpr - > t5);
  printf("  t6       0x%x\n", gpr - > t6);
}

// 任务2：补充中断处理程序
void handle_interrupt(struct trapframe * tf) {
  /* 请提取tf->cause中的中断原因码（使用SCAUSE_MASK_ECODE掩码） */
  uint64 cause_code = tf - > cause & SCAUSE_MASK_ECODE;

  switch (cause_code) {
    /* 处理UserSoft类型中断，打印"UserSoft interrupt!" */
    case UserSoft:
      printf("UserSoft interrupt!\n");
      break;
      /* 处理未知中断，打印"Unknown interrupt! Code = %d\n"及原因码 */
    default:
      printf("Unknown interrupt! Code = %d\n", cause_code);
      break;
  }
}

// 任务1：补充异常处理程序
void handle_exception(struct trapframe * tf) {
  /* 请提取tf->cause中的异常原因码（使用SCAUSE_MASK_ECODE掩码） */
  uint64 cause_code = tf - > cause & SCAUSE_MASK_ECODE;

  /* 打印"Exception occurred! Cause: %d \n"及原因码 */
  printf("Exception occurred! Cause: %d\n", cause_code);

  /* 调用print_csr打印CSR状态 */
  print_csr(tf);
}

// 中断和异常处理的入口
static inline void trap_handler(struct trapframe * tf) {
  //在以下部分写出完成任务的代码，设置中断和异常处理的入口，与第二关任务代码一致
  /*********Begin*********/
  // TODO 1：补充“判断是否为中断”的条件（基于 scause 寄存器的中断标记位）
  if (tf - > cause & SCAUSE_MASK_INTERRUPT) {
    // TODO 2：补充“中断时调用的处理函数”
    handle_interrupt(tf);
  } else {
    // TODO 3：补充“异常时调用的处理函数”
    handle_exception(tf);
    tf - > epc = tf - > epc + 4; // 异常后调整返回地址，跳过出错指令
  }
  /*********End**********/
}

void trap(struct trapframe * tf) {
  trap_handler(tf);
}
