#include "defs.h"
#include "trap.h"
#include "print.h"

// 声明汇编陷阱向量（需在汇编文件中实现，这里仅做外部声明）
extern void trap_vector();

void kernel_trap_init()
{
	// 设置陷阱向量基地址
	w_stvec((uint64)trap_vector);
	// 开启中断
	intr_on();
}

void init_interrupt() {
	kernel_trap_init();
}

void print_trapframe(struct trapframe *tf) {
	printf("trapframe at %p\n", tf);
	print_regs(&tf->gpr);
	printf("  status   0x%lx\n", tf->status);
	printf("  epc      0x%lx\n", tf->epc);
	printf("  stval    0x%lx\n", tf->stval);
	printf("  cause    0x%lx\n", tf->cause);
}

void print_csr(struct trapframe *tf) {
	printf("  status   0x%lx\n", tf->status);
	printf("  epc      0x%lx\n", tf->epc);
	printf("  stval    0x%lx\n", tf->stval);  // 修正拼写错误 staval -> stval
	printf("  cause    0x%lx\n", tf->cause);
}

void print_regs(struct pushregs *gpr) {
	printf("  zero     0x%lx\n", gpr->zero);
	printf("  ra       0x%lx\n", gpr->ra);
	printf("  sp       0x%lx\n", gpr->sp);
	printf("  gp       0x%lx\n", gpr->gp);
	printf("  tp       0x%lx\n", gpr->tp);
	printf("  t0       0x%lx\n", gpr->t0);
	printf("  t1       0x%lx\n", gpr->t1);
	printf("  t2       0x%lx\n", gpr->t2);
	printf("  s0       0x%lx\n", gpr->s0);
	printf("  s1       0x%lx\n", gpr->s1);
	printf("  a0       0x%lx\n", gpr->a0);
	printf("  a1       0x%lx\n", gpr->a1);
	printf("  a2       0x%lx\n", gpr->a2);
	printf("  a3       0x%lx\n", gpr->a3);
	printf("  a4       0x%lx\n", gpr->a4);
	printf("  a5       0x%lx\n", gpr->a5);
	printf("  a6       0x%lx\n", gpr->a6);
	printf("  a7       0x%lx\n", gpr->a7);
	printf("  s2       0x%lx\n", gpr->s2);
	printf("  s3       0x%lx\n", gpr->s3);
	printf("  s4       0x%lx\n", gpr->s4);
	printf("  s5       0x%lx\n", gpr->s5);
	printf("  s6       0x%lx\n", gpr->s6);
	printf("  s7       0x%lx\n", gpr->s7);
	printf("  s8       0x%lx\n", gpr->s8);
	printf("  s9       0x%lx\n", gpr->s9);
	printf("  s10      0x%lx\n", gpr->s10);
	printf("  s11      0x%lx\n", gpr->s11);
	printf("  t3       0x%lx\n", gpr->t3);
	printf("  t4       0x%lx\n", gpr->t4);
	printf("  t5       0x%lx\n", gpr->t5);
	printf("  t6       0x%lx\n", gpr->t6);
}

// 中断处理程序
void handle_interrupt(struct trapframe *tf) {
	uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
	switch (cause_code) {
		case UserSoft:  // 软件中断
		printf("UserSoft interrupt!\n");  // 补充换行符，优化输出
		break;
	case SupervisorSoft:
		printf("SupervisorSoft interrupt!\n");
		break;
	case UserTimer:
		printf("UserTimer interrupt!\n");
		break;
	case SupervisorTimer:
		printf("SupervisorTimer interrupt!\n");
		break;
	case UserExternal:
		printf("UserExternal interrupt!\n");
		break;
	case SupervisorExternal:
		printf("SupervisorExternal interrupt!\n");
		break;
	default:
		printf("Unknown interrupt! Code = %ld\n", cause_code);
		break;
	}
}

// 异常处理程序
void handle_exception(struct trapframe *tf) {
	uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
	const char* exception_name = "Unknown Exception";
	// 映射异常码到异常名称
	switch (cause_code) {
		case InstructionMisaligned: exception_name = "InstructionMisaligned"; break;
		case InstructionAccessFault: exception_name = "InstructionAccessFault"; break;
		case IllegalInstruction: exception_name = "IllegalInstruction"; break;
		case Breakpoint: exception_name = "Breakpoint"; break;
		case LoadMisaligned: exception_name = "LoadMisaligned"; break;
		case LoadAccessFault: exception_name = "LoadAccessFault"; break;
		case StoreMisaligned: exception_name = "StoreMisaligned"; break;
		case StoreAccessFault: exception_name = "StoreAccessFault"; break;
		case UserEnvCall: exception_name = "UserEnvCall"; break;
		case SupervisorEnvCall: exception_name = "SupervisorEnvCall"; break;
		case MachineEnvCall: exception_name = "MachineEnvCall"; break;
		case InstructionPageFault: exception_name = "InstructionPageFault"; break;
		case LoadPageFault: exception_name = "LoadPageFault"; break;
		case StorePageFault: exception_name = "StorePageFault"; break;
	}
	printf("Exception occurred! Cause: %ld (%s) \n", cause_code, exception_name);
	print_csr(tf);
}

// 中断和异常处理的入口
static inline void trap_handler(struct trapframe *tf) {
	if (tf->cause & SCAUSE_MASK_INTERRUPT) {
		// 处理中断
		handle_interrupt(tf);
	} else {
		// 处理异常
		handle_exception(tf);
		// 跳过引发异常的指令，避免无限陷阱
		tf->epc += 4;
	}
}

void trap(struct trapframe *tf) { 
	trap_handler(tf); 
}
