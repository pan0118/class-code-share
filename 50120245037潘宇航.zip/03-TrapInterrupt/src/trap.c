#include "defs.h"
#include "riscv.h"
#include "trap.h"
#include "print.h"

extern void trap_vector(void);

static int timer_ticks = 0;
static int interrupt_count = 0;
static int current_priority = 0;

#define TIMER_PRIORITY 1
#define HIGH_PRIORITY  2

void kernel_trap_init(void)
{
    w_stvec((uint64)trap_vector);
    intr_on();
}

void init_interrupt(void)
{
    kernel_trap_init();
}

void print_regs(struct pushregs *gpr)
{
    printf("ra: 0x%x\n", gpr->ra);
    printf("sp: 0x%x\n", gpr->sp);
}

void print_csr(struct trapframe *tf)
{
    printf("epc:   0x%x\n", tf->epc);
    printf("stval: 0x%x\n", tf->stval);
    printf("cause: 0x%x\n", tf->cause);
}

void print_trapframe(struct trapframe *tf)
{
    printf("trapframe at %p\n", tf);
    print_csr(tf);
}

/*
 * 模拟一个高优先级中断。
 * 这里是为了在实验输出中明显看到“中断嵌套”的效果。
 */
void handle_high_priority_interrupt(void)
{
    int old_priority = current_priority;

    if (HIGH_PRIORITY > current_priority) {
        current_priority = HIGH_PRIORITY;

        printf("  -> Nested interrupt enter\n");
        printf("  -> Current priority = %d\n", current_priority);
        printf("  -> Handle high priority interrupt\n");
        printf("  -> Nested interrupt return\n");

        current_priority = old_priority;
    }
}

/*
 * 模拟时钟中断处理函数。
 * 每调用一次，ticks 加 1。
 * 当 ticks == 2 时，模拟一个更高优先级中断插入。
 */
void handle_timer_interrupt(void)
{
    int old_priority = current_priority;

    interrupt_count++;
    timer_ticks++;

    current_priority = TIMER_PRIORITY;

    printf("\n[TIMER INTERRUPT]\n");
    printf("interrupt count = %d\n", interrupt_count);
    printf("timer ticks     = %d\n", timer_ticks);
    printf("priority        = %d\n", current_priority);

    if (timer_ticks == 2) {
        printf("High priority interrupt comes now\n");
        handle_high_priority_interrupt();
    }

    printf("Timer interrupt finished\n");

    current_priority = old_priority;
}

void handle_interrupt(struct trapframe *tf)
{
    uint64 cause = tf->cause & SCAUSE_MASK_ECODE;

    printf("\n[REAL INTERRUPT]\n");
    printf("cause = %d\n", cause);

    /*
     * Supervisor Timer Interrupt 的原因码一般是 5。
     * 如果平台真的触发时钟中断，就会走这里。
     */
    if (cause == 5) {
        handle_timer_interrupt();
    } else {
        printf("Unknown interrupt\n");
    }
}

void handle_exception(struct trapframe *tf)
{
    uint64 cause = tf->cause & SCAUSE_MASK_ECODE;

    printf("\n[EXCEPTION]\n");
    printf("cause = %d\n", cause);

    switch (cause) {
    case 3:
        printf("type  = Breakpoint\n");
        break;

    case 7:
        printf("type  = Store access fault\n");
        break;

    default:
        printf("type  = Other exception\n");
        break;
    }

    printf("epc   = 0x%x\n", tf->epc);
    printf("stval = 0x%x\n", tf->stval);
}

void trap_handler(struct trapframe *tf)
{
    if (tf->cause & SCAUSE_MASK_INTERRUPT) {
        handle_interrupt(tf);
    } else {
        handle_exception(tf);
        tf->epc = tf->epc + 4;
    }
}

void trap(struct trapframe *tf)
{
    trap_handler(tf);
}
