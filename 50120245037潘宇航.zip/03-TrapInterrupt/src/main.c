#include "defs.h"
#include "print.h"
#include "trap.h"

extern void handle_timer_interrupt(void);

void test_timer_and_nested_interrupt(void)
{
    printf("\n========== Timer And Nested Interrupt Test ==========\n");

    printf("\nCall timer interrupt first time\n");
    handle_timer_interrupt();

    printf("\nCall timer interrupt second time\n");
    handle_timer_interrupt();

    printf("\nCall timer interrupt third time\n");
    handle_timer_interrupt();

    printf("\n========== Test Finished ==========\n");
}

void main(void)
{
    printf("RISC-V Bootloader\n");
    printf("Hello XOS!\n");

    init_interrupt();

    test_timer_and_nested_interrupt();

    while (1) {
    }
}
