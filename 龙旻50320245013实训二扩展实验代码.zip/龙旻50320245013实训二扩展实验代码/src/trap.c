#include "defs.h"
#include "trap.h"

extern void trap_vector();
void kernel_trap_init()
{
	w_stvec((uint64)trap_vector);
    intr_on();
}
void init_interrupt() {
    kernel_trap_init();
}

void print_trapframe(struct trapframe *tf) {
    printf("trapframe at %p\n", tf);
    print_regs(&tf->gpr);
    printf("  status   0x%08x\n", tf->status);
    printf("  epc      0x%08x\n", tf->epc);
    printf("  staval   0x%08x\n", tf->stval);
    printf("  cause    0x%08x\n", tf->cause);
}

void print_csr(struct trapframe *tf) {
    printf("  status   0x%x\n", tf->status);
    printf("  epc      0x%x\n", tf->epc);
    printf("  staval   0x%x\n", tf->stval);
    printf("  cause    0x%x\n", tf->cause);
}
void print_regs(struct pushregs *gpr) {
    printf("  zero     0x%x\n", gpr->zero);
    printf("  ra       0x%x\n", gpr->ra);
    printf("  sp       0x%x\n", gpr->sp);
    printf("  gp       0x%x\n", gpr->gp);
    printf("  tp       0x%x\n", gpr->tp);
    printf("  t0       0x%x\n", gpr->t0);
    printf("  t1       0x%x\n", gpr->t1);
    printf("  t2       0x%x\n", gpr->t2);
    printf("  s0       0x%x\n", gpr->s0);
    printf("  s1       0x%x\n", gpr->s1);
    printf("  a0       0x%x\n", gpr->a0);
    printf("  a1       0x%x\n", gpr->a1);
    printf("  a2       0x%x\n", gpr->a2);
    printf("  a3       0x%x\n", gpr->a3);
    printf("  a4       0x%x\n", gpr->a4);
    printf("  a5       0x%x\n", gpr->a5);
    printf("  a6       0x%x\n", gpr->a6);
    printf("  a7       0x%x\n", gpr->a7);
    printf("  s2       0x%x\n", gpr->s2);
    printf("  s3       0x%x\n", gpr->s3);
    printf("  s4       0x%x\n", gpr->s4);
    printf("  s5       0x%x\n", gpr->s5);
    printf("  s6       0x%x\n", gpr->s6);
    printf("  s7       0x%x\n", gpr->s7);
    printf("  s8       0x%x\n", gpr->s8);
    printf("  s9       0x%x\n", gpr->s9);
    printf("  s10      0x%x\n", gpr->s10);
    printf("  s11      0x%x\n", gpr->s11);
    printf("  t3       0x%x\n", gpr->t3);
    printf("  t4       0x%x\n", gpr->t4);
    printf("  t5       0x%x\n", gpr->t5);
    printf("  t6       0x%x\n", gpr->t6);
}

// ============================================================
// 拓展实验：异常统计计数器
// ============================================================
static uint64 exc_count_total = 0;
static uint64 exc_count[32] = {0};
static uint64 int_count_total = 0;
static uint64 int_count[16] = {0};

void print_exception_stats(void) {
    printf("\n========== 异常统计报告 ==========\n");
    printf("异常总数: %d\n", exc_count_total);
    for (int i = 0; i < 32; i++) {
        if (exc_count[i] > 0) {
            printf("  异常码 %d: 触发 %d 次\n", i, exc_count[i]);
        }
    }
    printf("中断总数: %d\n", int_count_total);
    for (int i = 0; i < 16; i++) {
        if (int_count[i] > 0) {
            printf("  中断码 %d: 触发 %d 次\n", i, int_count[i]);
        }
    }
    printf("==================================\n\n");
}

// ============================================================
// 拓展实验：完善中断类型识别
// ============================================================
void handle_interrupt(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_INTERRUPT;
    int_count_total++;

    printf("\n[中断处理] 捕获到异步中断\n");
    printf("中断原因码: %d\n", cause_code);

    switch (cause_code) {
        case UserSoft:
            int_count[UserSoft]++;
            printf("中断类型: 用户模式软件中断 (User Software Interrupt)\n");
            printf("触发方式: 由S模式通过写入sip.USIP或M模式通过写入mip.USIP触发\n");
            break;
        case SupervisorSoft:
            int_count[SupervisorSoft]++;
            printf("中断类型: 监管者模式软件中断 (Supervisor Software Interrupt)\n");
            printf("触发方式: 跨核间通信或软件触发的IPI中断\n");
            break;
        case UserTimer:
            int_count[UserTimer]++;
            printf("中断类型: 用户模式定时器中断 (User Timer Interrupt)\n");
            printf("触发方式: 用户态时间片到期触发\n");
            break;
        case SupervisorTimer:
            int_count[SupervisorTimer]++;
            printf("中断类型: 监管者模式定时器中断 (Supervisor Timer Interrupt)\n");
            printf("触发方式: S模式时钟中断，用于抢占式调度和时钟管理\n");
            break;
        case UserExternal:
            int_count[UserExternal]++;
            printf("中断类型: 用户模式外部中断 (User External Interrupt)\n");
            printf("触发方式: UART、磁盘等外设产生的中断\n");
            break;
        case SupervisorExternal:
            int_count[SupervisorExternal]++;
            printf("中断类型: 监管者模式外部中断 (Supervisor External Interrupt)\n");
            printf("触发方式: 平台级中断控制器(PLIC)转发的外设中断\n");
            break;
        default:
            printf("中断类型: 未定义的中断\n");
            printf("错误说明: 该中断原因码(%d)在RISC-V特权规范中未定义\n", cause_code);
            break;
    }
    printf("中断辅助信息(stval): %p\n", tf->stval);
    printf("中断发生地址(epc):   %p\n", tf->epc);
    printf("CPU状态寄存器(status): %p\n\n", tf->status);
}

// ============================================================
// 拓展实验（来自实验报告）：完善异常类型识别
// ============================================================
void handle_exception(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    exc_count_total++;
    if (cause_code < 32) exc_count[cause_code]++;

    printf("\n[异常处理] 捕获到同步异常\n");
    printf("异常原因码: %d\n", cause_code);

    switch(cause_code) {
        case InstructionMisaligned:
            printf("异常类型: 指令地址未对齐 (Instruction Address Misaligned)\n");
            printf("错误说明: 指令地址不是4字节对齐（如跳转到奇数地址）\n");
            printf("解决方法: 检查跳转目标地址是否对齐到4字节边界\n");
            break;
        case InstructionAccessFault:
            printf("异常类型: 指令访问故障 (Instruction Access Fault)\n");
            printf("错误说明: 尝试从无执行权限或未映射的内存区域取指令\n");
            printf("解决方法: 检查页表权限或程序计数器是否指向无效地址\n");
            break;
        case IllegalInstruction:
            printf("异常类型: 非法指令 (Illegal Instruction)\n");
            printf("错误说明: CPU无法解析当前的机器码，通常由执行数据段或损坏的代码导致\n");
            printf("解决方法: 检查程序二进制是否与RISC-V指令集兼容\n");
            break;
        case Breakpoint:
            printf("异常类型: 断点异常 (Breakpoint)\n");
            printf("错误说明: 执行了EBREAK指令，常用于调试器\n");
            printf("解决方法: 调试结束应移除断点或由调试器接管处理\n");
            break;
        case LoadMisaligned:
            printf("异常类型: 加载地址未对齐 (Load Address Misaligned)\n");
            printf("错误说明: 加载操作（如ld/lw）的地址不是其数据宽度的自然对齐\n");
            printf("解决方法: 检查指针是否对齐，或使用非对齐加载指令\n");
            break;
        case LoadAccessFault:
            printf("异常类型: 加载访问故障 (Load Access Fault)\n");
            printf("错误说明: 尝试从无读权限或未映射的内存地址读取数据\n");
            printf("解决方法: 检查页表或确保访问的地址有效\n");
            break;
        case StoreMisaligned:
            printf("异常类型: 存储地址未对齐 (Store/AMO Address Misaligned)\n");
            printf("错误说明: 存储操作（如sd/sw）的地址不是其数据宽度的自然对齐\n");
            printf("解决方法: 检查指针是否对齐\n");
            break;
        case StoreAccessFault:
            printf("异常类型: 存储访问故障 (Store/AMO Access Fault)\n");
            printf("错误说明: 尝试写入无写权限或未映射的内存地址（如地址0x0）\n");
            printf("解决方法: 检查目标地址是否有效且有写权限\n");
            break;
        case UserEnvCall:
            printf("异常类型: 用户模式环境调用 (Environment Call from U-mode)\n");
            printf("错误说明: 用户态程序执行了ECALL指令，请求系统服务（系统调用）\n");
            printf("解决方法: 由内核处理系统调用请求\n");
            break;
        case SupervisorEnvCall:
            printf("异常类型: 监管者模式环境调用 (Environment Call from S-mode)\n");
            printf("错误说明: S模式执行了ECALL指令，通常向M模式固件请求服务\n");
            printf("解决方法: 由M模式固件(SBI)处理\n");
            break;
        case MachineEnvCall:
            printf("异常类型: 机器模式环境调用 (Environment Call from M-mode)\n");
            printf("错误说明: M模式执行了ECALL指令\n");
            break;
        case InstructionPageFault:
            printf("异常类型: 指令页错误 (Instruction Page Fault)\n");
            printf("错误说明: 取指令时的页表转换失败，页表项不存在或无执行权限\n");
            printf("解决方法: 处理缺页异常或检查页表权限\n");
            break;
        case LoadPageFault:
            printf("异常类型: 加载页错误 (Load Page Fault)\n");
            printf("错误说明: 读取数据时的页表转换失败\n");
            printf("解决方法: 处理缺页异常（第4章将实现）\n");
            break;
        case StorePageFault:
            printf("异常类型: 存储页错误 (Store/AMO Page Fault)\n");
            printf("错误说明: 写入数据时的页表转换失败\n");
            printf("解决方法: 处理缺页异常（第4章将实现）\n");
            break;
        default:
            printf("异常类型: 未定义的异常\n");
            printf("错误说明: 原因码 %d 在RISC-V特权规范中未分配\n", cause_code);
            break;
    }

    printf("异常辅助信息(stval): %p\n", tf->stval);
    printf("异常发生地址(epc):   %p\n", tf->epc);
    printf("CPU状态寄存器(status): %p\n\n", tf->status);
}

// 中断和异常处理的入口
static inline void trap_handler(struct trapframe *tf) {

    if (tf->cause & SCAUSE_MASK_INTERRUPT) {
        handle_interrupt(tf);
    } else {
        handle_exception(tf);
        tf->epc = tf->epc + 4;
    }
}

void trap(struct trapframe *tf) { trap_handler(tf); }
