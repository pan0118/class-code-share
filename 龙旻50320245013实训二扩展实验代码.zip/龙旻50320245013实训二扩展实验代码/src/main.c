#include "print.h"
#include "trap.h"

// ============================================================
// 测试4: 触发存储访问故障异常 (Store Access Fault, cause=7)
// 错误说明: 尝试向地址0x0写入数据
// ============================================================
void test_store_access_fault() {
    printf("\n>>> [测试4] 触发存储访问故障 (Store Access Fault)\n");
    printf(">>> 即将执行: *(int *)0x00000000 = 100\n");
    *(int *)0x00000000 = 100;
    printf(">>> 成功从异常返回! epc已跳过出错指令.\n");
}

// ============================================================
// 测试5: 触发加载访问故障异常 (Load Access Fault, cause=5)
// 错误说明: 尝试从地址0x0读取数据
// ============================================================
void test_load_access_fault() {
    printf("\n>>> [测试5] 触发加载访问故障 (Load Access Fault)\n");
    printf(">>> 即将执行: int x = *(volatile int *)0x00000000\n");
    volatile int x = *(volatile int *)0x00000000;
    printf(">>> 成功从异常返回! 读取值: %d (无效,epc已跳过)\n", x);
}

// ============================================================
// 测试2: 触发非法指令异常 (Illegal Instruction, cause=2)
// 错误说明: 使用内联汇编嵌入非法机器码 0x00000000
// ============================================================
void test_illegal_instruction() {
    printf("\n>>> [测试2] 触发非法指令异常 (Illegal Instruction)\n");
    printf(">>> 即将执行内联汇编嵌入非法指令字 0x00000000\n");
    asm volatile(".word 0x00000000");
    printf(">>> 成功从异常返回! epc已跳过非法指令.\n");
}

// ============================================================
// 测试7: 再次触发存储访问故障（触发多次同一类型异常）
// 用于验证异常统计计数器功能
// ============================================================
void test_store_access_fault_again() {
    printf("\n>>> [测试7] 再次触发存储访问故障 (Store Access Fault)\n");
    printf(">>> 即将执行: *(int *)0x00000000 = 200\n");
    *(int *)0x00000000 = 200;
    printf(">>> 成功从异常返回! epc已跳过出错指令.\n");
}

// ============================================================
// 测试5b: 再次触发加载访问故障（触发多次同一类型异常）
// ============================================================
void test_load_access_fault_again() {
    printf("\n>>> [测试5] 再次触发加载访问故障 (Load Access Fault)\n");
    printf(">>> 即将执行: int y = *(volatile int *)0x00000004\n");
    volatile int y = *(volatile int *)0x00000004;
    printf(">>> 成功从异常返回! 读取值: %d (无效,epc已跳过)\n", y);
}

// ============================================================
// 测试入口：依次触发多种异常并观察处理结果
// ============================================================
void test_interrupts() {
    printf("\n");
    printf("+==============================================+\n");
    printf("|        XOS 异常处理综合测试套件              |\n");
    printf("|  拓展实验: 多种异常触发与类型识别验证         |\n");
    printf("+==============================================+\n");

    // 测试非法指令异常
    test_illegal_instruction();

    // 测试加载访问故障
    test_load_access_fault();

    // 测试存储访问故障
    test_store_access_fault();

    // 再次测试存储访问故障（验证统计计数）
    test_store_access_fault_again();

    // 再次测试加载访问故障（验证统计计数）
    test_load_access_fault_again();

    // 打印异常统计报告
    print_exception_stats();

    printf("\n>>> 所有异常测试完成! 进入无限循环...\n");
}

void main(void) {
    printf("RISC-V Bootloader\n");
    printf("Hello XOS! -- 中断与异常处理实验\n\n");

    // 初始化中断处理
    init_interrupt();

    // 运行异常测试套件
    test_interrupts();

    // 进入无限循环
    while (1) {
    }
}
