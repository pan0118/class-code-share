#ifndef _PRINT_H_
#define _PRINT_H_

#include "types.h"

void printf(const char *fmt, ...);
void panic(const char *msg);

#endif
