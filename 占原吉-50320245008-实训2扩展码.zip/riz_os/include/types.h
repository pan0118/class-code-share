#ifndef _TYPES_H_
#define _TYPES_H_

typedef unsigned long long uint64;
typedef unsigned int       uint32;
typedef unsigned short     uint16;
typedef unsigned char      uint8;

#endif
