#ifndef _DEFS_H_
#define _DEFS_H_

#include "types.h"
#include "riscv.h"
#include "sbi.h"
#include "print.h"
#include "trap.h"

#endif
