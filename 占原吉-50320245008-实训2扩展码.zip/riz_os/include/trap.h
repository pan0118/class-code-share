#ifndef _TRAP_H_
#define _TRAP_H_

#include "types.h"

struct pushregs {
    uint64 zero, ra, sp, gp, tp;
    uint64 t0, t1, t2;
    uint64 s0, s1;
    uint64 a0, a1, a2, a3, a4, a5, a6, a7;
    uint64 s2, s3, s4, s5, s6, s7, s8, s9, s10, s11;
    uint64 t3, t4, t5, t6;
};

struct trapframe {
    struct pushregs gpr;
    uint64 status;
    uint64 epc;
    uint64 stval;
    uint64 cause;
};

void trap(struct trapframe *tf);
void init_interrupt(void);

#endif
