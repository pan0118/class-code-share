#ifndef _RISCV_H_
#define _RISCV_H_

#include "types.h"

static inline uint64 r_mstatus(void)
{
    uint64 x;
    asm volatile("csrr %0, mstatus" : "=r"(x));
    return x;
}

static inline void w_mstatus(uint64 x)
{
    asm volatile("csrw mstatus, %0" : : "r"(x));
}

static inline void w_mie(uint64 x)
{
    asm volatile("csrw mie, %0" : : "r"(x));
}

static inline void w_mepc(uint64 x)
{
    asm volatile("csrw mepc, %0" : : "r"(x));
}

static inline uint64 r_mepc(void)
{
    uint64 x;
    asm volatile("csrr %0, mepc" : "=r"(x));
    return x;
}

static inline void w_mtvec(uint64 x)
{
    asm volatile("csrw mtvec, %0" : : "r"(x));
}

#endif
