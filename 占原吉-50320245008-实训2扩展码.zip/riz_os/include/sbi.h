#ifndef _SBI_H_
#define _SBI_H_

#include "types.h"

struct sbiret {
    uint64 error;
    uint64 value;
};

void sbi_putchar(int ch);
int  sbi_getchar(void);
void sbi_shutdown(void);

#endif
