#include "include/types.h"

struct sbiret {
    uint64 error;
    uint64 value;
};

static struct sbiret sbi_ecall(uint64 ext, uint64 fid,
                                uint64 a0, uint64 a1,
                                uint64 a2, uint64 a3,
                                uint64 a4, uint64 a5)
{
    struct sbiret ret;
    register uint64 a7 asm("a7") = ext;
    register uint64 a6 asm("a6") = fid;
    register uint64 r_a0 asm("a0") = a0;
    register uint64 r_a1 asm("a1") = a1;
    register uint64 r_a2 asm("a2") = a2;
    register uint64 r_a3 asm("a3") = a3;
    register uint64 r_a4 asm("a4") = a4;
    register uint64 r_a5 asm("a5") = a5;

    asm volatile("ecall"
                 : "+r"(r_a0), "+r"(r_a1)
                 : "r"(a7), "r"(a6), "r"(r_a2),
                   "r"(r_a3), "r"(r_a4), "r"(r_a5)
                 : "memory");

    ret.error = r_a0;
    ret.value = r_a1;
    return ret;
}

void sbi_putchar(int ch)
{
    sbi_ecall(0x01, 0x00, ch, 0, 0, 0, 0, 0);
}

int sbi_getchar(void)
{
    struct sbiret ret = sbi_ecall(0x01, 0x02, 0, 0, 0, 0, 0, 0);
    return (int)ret.value;
}

void sbi_shutdown(void)
{
    sbi_ecall(0x08, 0x00, 0, 0, 0, 0, 0, 0);
}
