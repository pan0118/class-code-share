#include "include/defs.h"

extern char trap_vector[];

#define SCAUSE_MASK_INTERRUPT (1ULL << 63)
#define SCAUSE_MASK_ECODE     0x7FFFFFFFFFFFFFFFULL

#define UserSoft          0
#define SupervisorSoft    1
#define MachineTimerInt   7

void w_stvec(uint64 addr)
{
    asm volatile("csrw stvec, %0" : : "r"(addr));
}

void intr_on(void)
{
    asm volatile("csrsi sstatus, 2");
}

void kernel_trap_init(void)
{
    w_stvec((uint64)trap_vector);
    intr_on();
}

void init_interrupt(void)
{
    kernel_trap_init();
}

void print_regs(struct pushregs *gpr)
{
    printf(" zero 0x%x\n", gpr->zero);
    printf(" ra 0x%x\n", gpr->ra);
    printf(" sp 0x%x\n", gpr->sp);
    printf(" gp 0x%x\n", gpr->gp);
    printf(" tp 0x%x\n", gpr->tp);
    printf(" t0 0x%x\n", gpr->t0);
    printf(" t1 0x%x\n", gpr->t1);
    printf(" t2 0x%x\n", gpr->t2);
    printf(" s0 0x%x\n", gpr->s0);
    printf(" s1 0x%x\n", gpr->s1);
    printf(" a0 0x%x\n", gpr->a0);
    printf(" a1 0x%x\n", gpr->a1);
    printf(" a2 0x%x\n", gpr->a2);
    printf(" a3 0x%x\n", gpr->a3);
    printf(" a4 0x%x\n", gpr->a4);
    printf(" a5 0x%x\n", gpr->a5);
    printf(" a6 0x%x\n", gpr->a6);
    printf(" a7 0x%x\n", gpr->a7);
    printf(" s2 0x%x\n", gpr->s2);
    printf(" s3 0x%x\n", gpr->s3);
    printf(" s4 0x%x\n", gpr->s4);
    printf(" s5 0x%x\n", gpr->s5);
    printf(" s6 0x%x\n", gpr->s6);
    printf(" s7 0x%x\n", gpr->s7);
    printf(" s8 0x%x\n", gpr->s8);
    printf(" s9 0x%x\n", gpr->s9);
    printf(" s10 0x%x\n", gpr->s10);
    printf(" s11 0x%x\n", gpr->s11);
    printf(" t3 0x%x\n", gpr->t3);
    printf(" t4 0x%x\n", gpr->t4);
    printf(" t5 0x%x\n", gpr->t5);
    printf(" t6 0x%x\n", gpr->t6);
}

void print_trapframe(struct trapframe *tf)
{
    printf(" trapframe at %p\n", tf);
    print_regs(&tf->gpr);
    printf(" status %08x\n", (unsigned int)tf->status);
    printf(" epc %08x\n", (unsigned int)tf->epc);
    printf(" stval %08x\n", (unsigned int)tf->stval);
    printf(" cause %08x\n", (unsigned int)tf->cause);
}

void print_csr(struct trapframe *tf)
{
    printf("status: %08x\n", (unsigned int)tf->status);
    printf("epc: %08x\n", (unsigned int)tf->epc);
    printf("stval: %08x\n", (unsigned int)tf->stval);
    printf("cause: %08x\n", (unsigned int)tf->cause);
}

void handle_interrupt(struct trapframe *tf)
{
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    switch (cause_code) {
    case UserSoft:
        printf("User software interrupt!\n");
        break;
    case SupervisorSoft:
        printf("Supervisor software interrupt!\n");
        break;
    case MachineTimerInt:
        printf("Timer interrupt! cause=%d\n", (int)cause_code);
        break;
    default:
        printf("Unknown interrupt! Cause: %d\n", (int)cause_code);
        break;
    }
}

void handle_exception(struct trapframe *tf)
{
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    switch (cause_code) {
    case 2:
        printf("Illegal instruction exception!\n");
        break;
    case 7:
        printf("Exception occurred! Cause: %d\n", (int)cause_code);
        print_csr(tf);
        break;
    case 8:
        printf("Environment call from U-mode (ecall)!\n");
        break;
    default:
        printf("Exception occurred! Cause: %d\n", (int)cause_code);
        print_csr(tf);
        break;
    }
}

void trap_handler(struct trapframe *tf)
{
    if (tf->cause & SCAUSE_MASK_INTERRUPT) {
        handle_interrupt(tf);
    } else {
        handle_exception(tf);
        tf->epc += 4;
    }
}

void trap(struct trapframe *tf)
{
    trap_handler(tf);
}
