#include "include/types.h"

void sbi_putchar(int ch);
void sbi_shutdown(void);

typedef __builtin_va_list va_list;
#define va_start(v, l) __builtin_va_start(v, l)
#define va_arg(v, T)   __builtin_va_arg(v, T)
#define va_end(v)      __builtin_va_end(v)

static void print_hex(unsigned long long val, int digits)
{
    char buf[32];
    int i;
    for (i = 0; i < digits; i++) {
        int nibble = (val >> ((digits - 1 - i) * 4)) & 0xf;
        buf[i] = (nibble < 10) ? ('0' + nibble) : ('a' + nibble - 10);
    }
    buf[digits] = '\0';
    for (i = 0; buf[i]; i++)
        sbi_putchar(buf[i]);
}

static void print_dec(unsigned long long val)
{
    char buf[32];
    int i = 0;
    if (val == 0) {
        sbi_putchar('0');
        return;
    }
    while (val > 0) {
        buf[i++] = '0' + (val % 10);
        val /= 10;
    }
    while (i > 0)
        sbi_putchar(buf[--i]);
}

static void print_str(const char *s)
{
    while (*s)
        sbi_putchar(*s++);
}

void printf(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);

    while (*fmt) {
        if (*fmt == '%') {
            fmt++;
            switch (*fmt) {
            case 'd':
                print_dec(va_arg(args, int));
                break;
            case 'x':
            case 'p':
                if (*fmt == 'p') {
                    sbi_putchar('0');
                    sbi_putchar('x');
                }
                print_hex(va_arg(args, unsigned long long),
                          (*fmt == 'p') ? 16 : 8);
                break;
            case 'c':
                sbi_putchar(va_arg(args, int));
                break;
            case 's':
                print_str(va_arg(args, const char *));
                break;
            case '%':
                sbi_putchar('%');
                break;
            default:
                sbi_putchar('%');
                sbi_putchar(*fmt);
                break;
            }
        } else if (*fmt == '\n') {
            sbi_putchar('\r');
            sbi_putchar('\n');
        } else {
            sbi_putchar(*fmt);
        }
        fmt++;
    }

    va_end(args);
}

void panic(const char *msg)
{
    printf("PANIC: %s\n", msg);
    sbi_shutdown();
    while (1)
        ;
}
