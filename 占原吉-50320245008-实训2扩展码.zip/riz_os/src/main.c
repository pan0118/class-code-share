#include "include/defs.h"

int main(void)
{
    printf("RISC-V Bootloader\n");
    printf("Hello XOS!\n");

    printf("Initializing trap vector...\n");
    init_interrupt();
    printf("Trap vector set to stvec, interrupts enabled.\n");

    printf("Testing printf format: %%d=%d %%x=%x %%c=%c %%s=%s\n",
           123, 0xDEAD, 'Z', "ok");

    printf("\n");
    printf("=== System Ready ===\n");
    printf("Trap framework is loaded.\n");
    printf("On headge platform, trigger tests via:\n");
    printf("  *(int *)0 = 100  -> cause=7 exception\n");
    printf("  illegal instr   -> cause=2 exception\n");
    printf("  ecall in U-mode -> cause=8 exception\n");

    while (1)
        ;
    return 0;
}
