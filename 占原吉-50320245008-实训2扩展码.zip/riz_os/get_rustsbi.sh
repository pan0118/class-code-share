#!/bin/bash
# 下载 RustSBI 固件到 lib/rustsbi-qemu/
mkdir -p lib/rustsbi-qemu
cd lib/rustsbi-qemu

# RustSBI 0.4.0 for QEMU virt machine
# 如果下载失败，手动访问 https://github.com/rustsbi/rustsbi-qemu/releases
wget -q https://github.com/rustsbi/rustsbi-qemu/releases/download/v0.4.0/rustsbi-qemu-release.zip
unzip -o rustsbi-qemu-release.zip
mv rustsbi-qemu* rustsbi-qemu.bin 2>/dev/null || true
rm -f rustsbi-qemu-release.zip

echo "RustSBI firmware ready."
echo "Now run: make clean && make && make run"
