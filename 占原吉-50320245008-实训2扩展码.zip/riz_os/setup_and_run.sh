#!/bin/bash
# ==========================================
#  RISC-V 实训项目 — Ubuntu 虚拟机运行脚本
# ==========================================

echo "=== 安装 RISC-V 工具链 ==="
sudo apt update
sudo apt install -y gcc-riscv64-unknown-elf qemu-system-misc

echo ""
echo "=== 编译项目 ==="
make clean 2>/dev/null
make

echo ""
echo "=== 用 QEMU 运行 ==="
echo "(按 Ctrl+A 再按 X 可以退出 QEMU)"
echo "========================================"
make run
